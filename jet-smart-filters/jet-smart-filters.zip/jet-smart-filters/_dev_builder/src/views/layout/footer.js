const Footer = () => {
	return (
		<div className="jsf-listings-footer">
			<a href="#">Documentation</a>
		</div>
	);
};

export default Footer;
