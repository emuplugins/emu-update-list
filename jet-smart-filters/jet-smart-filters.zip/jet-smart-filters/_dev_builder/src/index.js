import App from './app';

window.JSFBuilderApp = new App();
