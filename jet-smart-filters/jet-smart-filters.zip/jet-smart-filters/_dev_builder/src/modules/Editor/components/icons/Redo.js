const Redo = (props) => (
	<svg width="24" height="24" viewBox="0 0 24 24" aria-hidden="true" focusable="false" {...props}>
		<path d="M15.6 6.5l-1.1 1 2.9 3.3H8c-.9 0-1.7.3-2.3.9-1.4 1.5-1.4 4.2-1.4 5.6v.2h1.5v-.3c0-1.1 0-3.5 1-4.5.3-.3.7-.5 1.3-.5h9.2L14.5 15l1.1 1.1 4.6-4.6-4.6-5z"></path>
	</svg>
);

export default Redo;