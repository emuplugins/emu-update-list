<?php return array('dependencies' => array('react', 'wp-components', 'wp-hooks', 'wp-i18n'), 'version' => '0c78f2f680a61b997783');
