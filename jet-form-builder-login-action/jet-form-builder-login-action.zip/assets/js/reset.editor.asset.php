<?php return array('dependencies' => array('react', 'wp-components', 'wp-data', 'wp-hooks', 'wp-i18n', 'wp-primitives'), 'version' => '5a81f6e39d813b2e79cf');
