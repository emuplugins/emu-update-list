<?php
/**
 * Silence is golden
 *
 * @package  Cherry
 * @category Core
 * @author   Cherry Team
 * @license  GPL-2.0+
 */
