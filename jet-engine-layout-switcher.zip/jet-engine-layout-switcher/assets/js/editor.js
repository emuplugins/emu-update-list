(function( $ ) {

	'use strict';

	const JetEngineLayoutSwitcherEditor = {

		init: function() {

			var FinderWidgetControlItemView = elementor.modules.controls.Select2.extend({

				hasOptions: false,

				addOptions: function addOptions() {
					var widgetName = this.model.get( 'widget_name' );

					if ( ! widgetName ) {
						return;
					}

					if ( ! window.elementorFrontend ) {
						return;
					}

					var $body = window.elementorFrontend.elements.$body,
						$widgets = $body.find( '.elementor-widget-' + widgetName );

					if ( ! $widgets.length ) {
						return;
					}

					// Remove nested widgets.
					$widgets = $widgets.filter( function() {
						return ! $( this ).closest( '[data-elementor-type="jet-listing-items"]' ).length;
					} );

					if ( ! $widgets.length ) {
						return;
					}

					var result = {},
						widgetTitle = '';

					if ( elementor.config && elementor.config.widgets && elementor.config.widgets[ widgetName ] ) {
						widgetTitle = elementor.config.widgets[ widgetName ].title;
					}

					this.ui.select.prop( 'disabled', true );

					$widgets.each( function() {
						var widgetId = $( this ).data( 'id' ),
							attrId = $( this ).attr( 'id' ) || '',
							modelId = $( this ).data( 'model-cid' ) || '',
							customTitle = '';

						if ( result[ widgetId ] ) {
							return;
						}

						if ( modelId
							&& window.elementorFrontend.config.elements.data[ modelId ]
							&& window.elementorFrontend.config.elements.data[ modelId ].attributes
							&& window.elementorFrontend.config.elements.data[ modelId].attributes._title
						) {
							customTitle = window.elementorFrontend.config.elements.data[ modelId].attributes._title;
						}

						if ( customTitle ) {
							customTitle = ' - ' + customTitle;
						}

						if ( attrId ) {
							attrId = ' - #' + attrId;
						}

						result[ widgetId ] = widgetTitle  + ' (' + widgetId + ')' + customTitle + attrId;
					} );

					this.hasOptions = true;

					this.model.set( 'options', result );
					this.render();
				},

				onReady: function onReady() {
					if ( ! this.hasOptions ) {
						this.addOptions();
					}
				}
			});

			// Add controls views
			elementor.addControlView( 'jet-finder-widget', FinderWidgetControlItemView );
		}

	};

	$( window ).on( 'elementor:init', JetEngineLayoutSwitcherEditor.init );

}( jQuery ));
