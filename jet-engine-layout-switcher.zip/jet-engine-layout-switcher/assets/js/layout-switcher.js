( function( $ ) {

	"use strict";

	const JetEngineLayoutSwitcher = {

		activeClass: 'je-layout-switcher__btn--active',
		loadingClass: 'je-layout-switcher--loading',

		elementorInit: function() {
			window.elementorFrontend.hooks.addAction(
				'frontend/element_ready/jet-engine-layout-switcher.default',
				JetEngineLayoutSwitcher.initLayoutSwitcher
			);
		},

		commonInit: function() {
			$( document ).on(
				'click.JetEngineLayoutSwitcher',
				'.je-layout-switcher__btn',
				JetEngineLayoutSwitcher.switchLayout
			);
		},

		initLayoutSwitcher: function( $scope ) {
			const $activeBtn = $scope.find( '.' + JetEngineLayoutSwitcher.activeClass );

			if ( ! $activeBtn.length || $activeBtn.data( 'is-default' ) ) {
				return;
			}

			const $wrapper = $scope.find( '.je-layout-switcher' );
			const widgetId = $wrapper.data( 'widget-id' );
			const activeSettings = $activeBtn.data( 'settings' );

			JetEngineLayoutSwitcher.updateElementSettings( widgetId, activeSettings );
		},

		switchLayout: function( event ) {
			const $btn = $( event.currentTarget );
			const activeClass = JetEngineLayoutSwitcher.activeClass;

			if ( $btn.hasClass( activeClass ) ) {
				return;
			}

			const $wrapper = $btn.closest( '.je-layout-switcher' );
			const widgetId = $wrapper.data( 'widget-id' );

			const slug = $btn.data( 'slug' );
			const settings = $btn.data( 'settings' );
			const isDefaultLayout = $btn.data( 'is-default' ) || false;

			const $activeBtn = $btn.closest( '.je-layout-switcher__group' ).find( '.' + activeClass );
			const activeSettings = $activeBtn.data( 'settings' );

			const isEditMode = window.elementorFrontend && window.elementorFrontend.isEditMode();

			if ( !isEditMode ) {
				// Update cookie
				$.ajax( {
					url: window.JetEngineSettings.ajaxlisting,
					type: 'POST',
					dataType: 'json',
					data: {
						action: 'jet_engine_ajax',
						jet_engine_action: 'jet_engine_switch_layout',
						widget_id: widgetId,
						layout: slug,
						settings: settings,
					},
				} );
			}

			// Update element data settings
			JetEngineLayoutSwitcher.updateElementSettings( widgetId, settings );

			const $container = $( '.elementor-element-' + widgetId + ' > .elementor-widget-container' );
			const $listing = $container.find( '.jet-listing-grid__items' ).first();
			const $slider = $listing.parent( '.jet-listing-grid__slider' );

			// Load new listings
			if ( settings.lisitng_id && activeSettings.lisitng_id && settings.lisitng_id !== activeSettings.lisitng_id ) {
				let navSettings = $listing.data( 'nav' ) || {};
				navSettings = JetEngine.ensureJSON( navSettings );

				let widgetSettings = navSettings.widget_settings || {};
				Object.assign( widgetSettings, settings );

				let ajaxOptions = {
					handler: 'get_listing',
					container: $container,
					masonry: false,
					slider: false,
					append: false,
					query: navSettings.query || {},
					widgetSettings: widgetSettings,
					extraProps: {
						switch_layout: 1,
						listing_query_id: $listing.data( 'query-id' ),
					}
				};

				if ( window.JetSmartFilters ) {
					const filterQueryId = widgetSettings._element_id ? widgetSettings._element_id : 'default';

					// Add the filtered query to the request
					if ( window.JetSmartFilters.filterGroups
						&& window.JetSmartFilters.filterGroups['jet-engine/' + filterQueryId]
						&& window.JetSmartFilters.filterGroups['jet-engine/' + filterQueryId].currentQuery
					) {
						Object.assign( ajaxOptions.extraProps, {
							filtered_query: window.JetSmartFilters.filterGroups['jet-engine/' + filterQueryId].currentQuery
						} );
					}

					// Update filters settings
					if ( window.JetSmartFilterSettings
						&& window.JetSmartFilterSettings.settings['jet-engine']
						&& window.JetSmartFilterSettings.settings['jet-engine'][ filterQueryId ]
					) {
						window.JetSmartFilterSettings.settings['jet-engine'][ filterQueryId ]['lisitng_id'] = settings.lisitng_id;
					}
				}

				$wrapper.addClass( JetEngineLayoutSwitcher.loadingClass );

				JetEngine.ajaxGetListing( ajaxOptions, function( response ) {
					JetEngine.widgetListingGrid( $container );
					JetEngineLayoutSwitcher.addLayoutCSS( $wrapper, widgetId, settings, isDefaultLayout );

					$wrapper.removeClass( JetEngineLayoutSwitcher.loadingClass );
				}, function() {
					$wrapper.removeClass( JetEngineLayoutSwitcher.loadingClass );
				} );

			} else {
				JetEngineLayoutSwitcher.addLayoutCSS( $wrapper, widgetId, settings, isDefaultLayout );
				JetEngineLayoutSwitcher.reInitMasonry( $listing, widgetId, settings );
				JetEngineLayoutSwitcher.reInitSlider( $slider );
			}

			// Update active class
			$btn.closest( '.je-layout-switcher__group' )
				.find( '.' + activeClass )
				.removeClass( activeClass );

			$btn.addClass( activeClass );

		},

		toggleListings: function( widgetId, showListingId ) {
			const $wrappers = $( '.elementor-element-' + widgetId + ' > .elementor-widget-container > .jet-listing-grid' );
			const $listing  = $wrappers.find( '> .jet-listing-grid--' + showListingId );

			if ( ! $listing.length ) {
				return false;
			}

			$wrappers.hide();
			$listing.closest( '.jet-listing-grid' ).show();

			return true;
		},

		addLayoutCSS: function( $wrapper, widgetId, settings, isDefaultLayout ) {
			let $styleTag = $( '#jet-engine-layout-switcher-custom-css-' + widgetId );
			let inlineCss = '';

			if ( ! $styleTag.length ) {

				$styleTag = $( '<style>', {
					id: 'jet-engine-layout-switcher-custom-css-' + widgetId
				} );

				$wrapper.append( $styleTag );
			}

			if ( isDefaultLayout ) {
				$styleTag.html( inlineCss );
				return;
			}

			const selector = '.elementor-element-' + widgetId + ' > .elementor-widget-container > .jet-listing-grid > .jet-listing-grid__items';
			const breakpoints = window.elementorFrontend.config.responsive.activeBreakpoints;

			if ( settings.columns ) {
				inlineCss += selector + ' { --columns: ' + settings.columns + '!important }';
			}

			Object.keys( breakpoints ).reverse().forEach( function( breakpointName ) {

				if ( ! settings[ 'columns_' + breakpointName ] ) {
					return;
				}

				const dir     = breakpoints[ breakpointName ].direction;
				const value   = breakpoints[ breakpointName ].value;
				const columns = settings[ 'columns_' + breakpointName ];

				inlineCss += ' @media(' + dir + '-width: ' + value + 'px) { ' + selector + ' { --columns: ' + columns + '!important } }';
			} );

			$styleTag.html( inlineCss );
		},

		updateElementSettings: function( widgetId, settings ) {
			let columnsSettings = {};

			Object.keys( settings ).forEach( function( settingName ) {
				if ( 0 === settingName.indexOf( 'column' ) ) {
					columnsSettings[ settingName ] = settings[settingName];
				}
			} );

			const $eWidget = $( '.elementor-element-' + widgetId );

			if ( $eWidget.length ) {
				$eWidget.data( 'settings', {
					...$eWidget.data( 'settings' ),
					...columnsSettings
				} );
			}
		},

		reInitMasonry: function( $listing, widgetId, settings ) {

			if ( ! $listing.hasClass( 'jet-listing-grid__masonry' ) ) {
				return;
			}

			// Todo: update `data-masonry-grid-options` for $masonry selector

			JetEngine.runMasonry( $listing );
		},

		reInitSlider: function( $slider ) {

			if ( ! $slider.length ) {
				return;
			}

			$slider.find( '> .jet-listing-grid__items' ).slick( 'unslick' );

			JetEngine.initSlider( $slider );
		}

	};

	$( window ).on( 'elementor/frontend/init', JetEngineLayoutSwitcher.elementorInit );

	JetEngineLayoutSwitcher.commonInit();

}( jQuery ) );