<?php
namespace Jet_Engine_Layout_Switcher;

class Render extends \Jet_Engine_Render_Base {

	private static $enqueue_assets = false;

	public function get_name() {
		return 'jet-engine-layout-switcher';
	}

	public function default_settings() {
		return array(
			'widget_id' => '',
			'view'      => 'elementor',
			'layouts'   => array(),
		);
	}

	public function render() {
		$settings = $this->get_settings();

		if ( empty( $settings['widget_id'] ) ) {
			printf(
				'<div class="jet-listing-notice">%1$s</div>',
				esc_html__( 'Please select the Listing Grid to show the Layout Switcher.', 'jet-engine' )
			);

			return;
		}

		if ( empty( $settings['layouts'] ) ) {
			return;
		}

		$listing_settings = $this->get_default_listing_settings();
		$is_edit_mode     = class_exists( 'Elementor\Plugin' ) && \Elementor\Plugin::instance()->editor->is_edit_mode();

		if ( empty( $listing_settings ) && ! $is_edit_mode ) {
			return;
		}

		$this->enqueue_assets();

		$cookie_key     = 'jet_engine_layout_' . esc_attr( $settings['widget_id'] );
		$cookie_value   = isset( $_COOKIE[ $cookie_key ] ) ? json_decode( wp_unslash( $_COOKIE[ $cookie_key ] ), true ) : false;
		$current_layout = ( ! empty( $cookie_value ) && ! empty( $cookie_value['layout'] ) ) ? $cookie_value['layout'] : false;

		$buttons_html           = '';
		$default_layout         = null;
		$active_layout_settings = null;

		$show_label = isset( $settings['show_label'] ) ? filter_var( $settings['show_label'], FILTER_VALIDATE_BOOLEAN ) : true;

		foreach ( $settings['layouts'] as $layout ) {

			$label = ! empty( $layout['label'] ) ? $layout['label'] : '';
			$slug  = $this->get_prepared_slug( $layout );
			$icon  = \Jet_Engine_Tools::render_icon( $layout['icon'], 'je-layout-switcher__btn-icon' );

			$is_default_layout = ! empty( $layout['is_default_layout'] ) ? filter_var( $layout['is_default_layout'], FILTER_VALIDATE_BOOLEAN ) : false;

			if ( $is_default_layout ) {
				$default_layout  = $slug;
				$layout_settings = $listing_settings;
			} else {
				$layout_settings = $this->get_layout_settings( $layout );
				$layout_settings = array_merge( $listing_settings, $layout_settings );
			}

			$button_attr = array(
				'class'         => array( 'je-layout-switcher__btn' ),
				'data-slug'     => esc_attr( $slug ),
				'data-settings' => htmlspecialchars( json_encode( $layout_settings ) ),
			);

			if ( $is_default_layout ) {
				$button_attr['data-is-default'] = '1';
			}

			if ( $current_layout === $slug || ( ! $current_layout && $is_default_layout ) ) {
				$button_attr['class'][] = 'je-layout-switcher__btn--active';
				$active_layout_settings = $layout_settings;
			}

			if ( ! $show_label && ! empty( $label ) ) {
				$button_attr['aria-label'] = esc_attr( $label );
				$label = '';
			}

			$button_html = sprintf(
				'<button %3$s>%1$s%2$s</button>',
				$icon,
				$label,
				\Jet_Engine_Tools::get_attr_string( $button_attr )
			);

			$buttons_html .= $button_html;
		}

		$layout_css = '';

		if ( $active_layout_settings && $current_layout && $current_layout !== $default_layout && ! $is_edit_mode ) {

			$selector = '.elementor-element-' . $settings['widget_id']  . ' > .elementor-widget-container > .jet-listing-grid > .jet-listing-grid__items';

			if ( ! empty( $active_layout_settings['columns'] ) ) {
				$layout_css .= $selector . ' { --columns: ' . $active_layout_settings['columns'] . '!important }';
			}

			$active_breakpoints = \Elementor\Plugin::$instance->breakpoints->get_active_breakpoints();
			$active_breakpoints = array_reverse( $active_breakpoints );

			foreach ( $active_breakpoints as $name => $breakpoint_obj ) {

				if ( empty( $active_layout_settings[ 'columns_' . $name ] ) ) {
					continue;
				}

				$dir   = $breakpoint_obj->get_direction();
				$value = $breakpoint_obj->get_value() . 'px';

				$layout_css .= sprintf(
					' @media(%1$s-width: %2$s) { %3$s { --columns: %4$s!important } }',
					$dir,
					$value,
					$selector,
					$active_layout_settings[ 'columns_' . $name ]
				);
			}

		}

		if ( ! empty( $layout_css ) ) {
			$layout_css = sprintf(
				'<style type="text/css" id="jet-engine-layout-switcher-custom-css-%1$s">%2$s</style>',
				esc_attr( $settings['widget_id'] ),
				$layout_css
			);
		}

		printf(
			'<div class="je-layout-switcher" data-widget-id="%1$s"><div class="je-layout-switcher__group" role="group">%2$s</div>%3$s</div>',
			esc_attr( $settings['widget_id'] ),
			$buttons_html,
			$layout_css
		);
	}

	public function get_prepared_slug( $layout ) {

		if ( ! empty( $layout['slug'] ) ) {
			$slug = $layout['slug'];
		} elseif ( ! empty( $layout['label'] ) ) {
			$slug = $layout['label'];
		} elseif ( ! empty( $layout['_id'] ) ) {
			$slug = 'layout' . '-' . $layout['_id'];
		} else {
			$slug = 'layout' . '-' . rand( 1000, 9999 );
		}

		// Sanitize slug.
		$slug = strtolower( $slug );
		$slug = remove_accents( $slug );
		$slug = preg_replace( '/[^a-z0-9\s\-\_]/', '', $slug );
		$slug = str_replace( ' ', '-', $slug );

		return $slug;
	}

	public function get_default_listing_settings() {

		$widget_id = $this->get_settings( 'widget_id' );
		$widget_settings = array();

		$elementor = \Elementor\Plugin::instance();
		$document  = $elementor->documents->get_current();

		if ( $document ) {
			$widget = \Elementor\Utils::find_element_recursive( $document->get_elements_data(), $widget_id );

			if ( $widget ) {
				$widget_instance = $elementor->elements_manager->create_element_instance( $widget );
				$widget_settings = $widget_instance->get_settings();
			}
		}

		return $this->get_layout_settings( $widget_settings );
	}

	public function get_layout_settings_keys() {
		return array(
			'lisitng_id',
			'columns',
		);
	}

	public function get_layout_settings( $settings = array() ) {

		if ( empty( $settings ) ) {
			return array();
		}

		$allowed = $this->get_layout_settings_keys();
		$allowed_regex = '/^(?:' . join( '|', $allowed ) . ')/';

		return array_filter( $settings, function ( $value, $setting ) use ( $allowed_regex ) {

			if ( preg_match( $allowed_regex, $setting ) && ! empty( $value ) ) {
				return true;
			}

			return false;
		}, ARRAY_FILTER_USE_BOTH );
	}

	public function enqueue_assets() {
		$is_edit_mode    = \Elementor\Plugin::$instance->editor->is_edit_mode();
		$is_preview_mode = \Elementor\Plugin::$instance->preview->is_preview_mode();

		if ( $is_edit_mode || $is_preview_mode || self::$enqueue_assets ) {
			return;
		}

		$css      = '';
		$css_path = JET_ENGINE_LAYOUT_SWITCHER_PATH . 'assets/css/layout-switcher.css';

		if ( is_file( $css_path ) && is_readable( $css_path ) ) {
			$css = file_get_contents( $css_path );
		}

		// Print inline css
		if ( ! empty( $css ) ) {
			printf( '<style>%s</style>', $css );
		}

		// Enqueue script
		wp_enqueue_script( 'jet-engine-layout-switcher' );

		self::$enqueue_assets = true;
	}

}
