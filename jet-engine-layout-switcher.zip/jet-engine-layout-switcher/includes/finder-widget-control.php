<?php
namespace Jet_Engine_Layout_Switcher;

class Finder_Widget_Control extends \Elementor\Control_Select2 {

	public function get_type() {
		return 'jet-finder-widget';
	}

	protected function get_default_settings() {
		return array_merge(
			parent::get_default_settings(),
			array(
				'widget_name' => '',
			)
		);
	}
}
