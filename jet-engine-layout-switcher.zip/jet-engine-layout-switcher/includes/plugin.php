<?php
namespace Jet_Engine_Layout_Switcher;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Main file
 */
class Plugin {

	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	/**
	 * Plugin constructor.
	 */
	private function __construct() {

		if ( ! function_exists( 'jet_engine' ) ) {
			return;
		}

		if ( ! version_compare( jet_engine()->get_version(), '3.2.2', '>=' ) ) {
			return;
		}

		$this->register_autoloader();

		add_action( 'init', array( $this, 'on_init' ), 12 );

		$this->on_load();

	}

	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Register autoloader.
	 */
	private function register_autoloader() {
		require JET_ENGINE_LAYOUT_SWITCHER_PATH . 'includes/autoloader.php';
		Autoloader::run();
	}

	/**
	 * Initialize plugin parts
	 *
	 * @return void
	 */
	public function on_init() {

		if ( did_action( 'elementor/init' ) ) {
			add_action( 'elementor/widgets/register',  array( $this, 'register_widget' ) );
			add_action( 'elementor/controls/register', array( $this, 'register_control' ) );

			add_action( 'elementor/editor/before_enqueue_scripts', array( $this, 'enqueue_editor_script' ) );

			add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'enqueue_icons_styles' ) );
			add_action( 'elementor/preview/enqueue_styles',      array( $this, 'enqueue_icons_styles' ) );
		}

		add_action( 'wp_enqueue_scripts', array( $this, 'register_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_styles' ) );

		add_action( 'jet-engine/listings/preview-scripts', array( $this, 'enqueue_preview_scripts' ) );

		add_filter( 'jet-engine/listing/render/default-settings',  array( $this, 'update_listing_default_settings' ) );
		add_filter( 'jet-engine/listing/grid/nav-widget-settings', array( $this, 'update_listing_nav_widget_settings' ), 10, 2 );

		add_action( 'wp_ajax_jet_engine_switch_layout',        array( $this, 'switch_layout' ) );
		add_action( 'wp_ajax_nopriv_jet_engine_switch_layout', array( $this, 'switch_layout' ) );

		add_filter( 'jet-engine/listing/render/jet-listing-grid/settings', array( $this, 'maybe_apply_layout_settings' ) );

		add_action( 'jet-engine/query-builder/query/after-query-setup', array( $this, 'set_filtered_query_on_switch_layout' ) );
		add_filter( 'jet-engine/listing/grid/posts-query-args',         array( $this, 'update_query_on_switch_layout' ), 10, 3 );

	}

	public function on_load() {
		add_action( 'jet-engine/listings/renderers/registered', array( $this, 'register_renderer' ) );
	}

	/**
	 * Register renderer class
	 *
	 * @param object $manager Listing manager instance

	 */
	public function register_renderer( $manager ) {
		$manager->register_render_class(
			'layout-switcher',
			array(
				'class_name' => '\Jet_Engine_Layout_Switcher\Render',
				'path'       => JET_ENGINE_LAYOUT_SWITCHER_PATH . 'includes/render.php',
			)
		);
	}

	public function register_widget( $widgets_manager ) {
		$widgets_manager->register( new Widget() );
	}

	public function register_control( $controls_manager ) {
		$controls_manager->register( new Finder_Widget_Control() );
	}

	public function enqueue_editor_script() {
		wp_enqueue_script(
			'jet-engine-layout-switcher-editor',
			JET_ENGINE_LAYOUT_SWITCHER_URL . 'assets/js/editor.js',
			array( 'jquery' ),
			JET_ENGINE_LAYOUT_SWITCHER_VERSION,
			true
		);
	}

	public function enqueue_icons_styles() {
		ob_start();
		?>
		.jet-engine-layout-switcher-icon:before {
			content: '';
			display: block;
			width: 1em;
			height: 1em;
			margin: 0 auto;
			background-position: center;
			background-repeat: no-repeat;
			background-size: contain;
			background-image: url("data:image/svg+xml,%3Csvg width='64' height='64' viewBox='0 0 64 64' fill='none' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M6 9C6 8.44772 6.44772 8 7 8H11C11.5523 8 12 8.44772 12 9V13C12 13.5523 11.5523 14 11 14H7C6.44772 14 6 13.5523 6 13V9ZM8 12V10H10V12H8Z' fill='%230F172A'/%3E%3Cpath d='M14 11C14 10.4477 14.4477 10 15 10H33C33.5523 10 34 10.4477 34 11C34 11.5523 33.5523 12 33 12H15C14.4477 12 14 11.5523 14 11Z' fill='%230F172A'/%3E%3Cpath d='M14 20C14 19.4477 14.4477 19 15 19H33C33.5523 19 34 19.4477 34 20C34 20.5523 33.5523 21 33 21H15C14.4477 21 14 20.5523 14 20Z' fill='%230F172A'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M7 17C6.44772 17 6 17.4477 6 18V22C6 22.5523 6.44772 23 7 23H11C11.5523 23 12 22.5523 12 22V18C12 17.4477 11.5523 17 11 17H7ZM8 19V21H10V19H8Z' fill='%230F172A'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M6 27C6 26.4477 6.44772 26 7 26H11C11.5523 26 12 26.4477 12 27V31C12 31.5523 11.5523 32 11 32H7C6.44772 32 6 31.5523 6 31V27ZM8 30V28H10V30H8Z' fill='%230F172A'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M36 35C35.4477 35 35 35.4477 35 36V42C35 42.5523 35.4477 43 36 43H42C42.5523 43 43 42.5523 43 42V36C43 35.4477 42.5523 35 42 35H36ZM37 37V41H41V37H37Z' fill='%230F172A'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M36 45C35.4477 45 35 45.4477 35 46V52C35 52.5523 35.4477 53 36 53H42C42.5523 53 43 52.5523 43 52V46C43 45.4477 42.5523 45 42 45H36ZM37 47V51H41V47H37Z' fill='%230F172A'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M45 36C45 35.4477 45.4477 35 46 35H52C52.5523 35 53 35.4477 53 36V42C53 42.5523 52.5523 43 52 43H46C45.4477 43 45 42.5523 45 42V36ZM51 41H47V37H51V41Z' fill='%230F172A'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M46 45C45.4477 45 45 45.4477 45 46V52C45 52.5523 45.4477 53 46 53H52C52.5523 53 53 52.5523 53 52V46C53 45.4477 52.5523 45 52 45H46ZM47 47V51H51V47H47Z' fill='%230F172A'/%3E%3Cpath fill-rule='evenodd' clip-rule='evenodd' d='M4 40C1.79086 40 0 38.2091 0 36V4C0 1.79086 1.79086 0 4 0H36C38.2091 0 40 1.79086 40 4V24H60C62.2091 24 64 25.7909 64 28V60C64 62.2091 62.2091 64 60 64H28C25.7909 64 24 62.2091 24 60V40H4ZM4 2H36C37.1046 2 38 2.89543 38 4V24H28C25.7909 24 24 25.7909 24 28H15C14.4477 28 14 28.4477 14 29C14 29.5523 14.4477 30 15 30H24V38H4C2.89543 38 2 37.1046 2 36V4C2 2.89543 2.89543 2 4 2ZM28 26H60C61.1046 26 62 26.8954 62 28V60C62 61.1046 61.1046 62 60 62H28C26.8954 62 26 61.1046 26 60V28C26 26.8954 26.8954 26 28 26Z' fill='%230F172A'/%3E%3Cpath d='M46.8853 10.4603L49.2535 12.8284C49.644 13.2189 49.644 13.8521 49.2535 14.2426C48.863 14.6332 48.2298 14.6332 47.8393 14.2426L44.3037 10.7071C43.9132 10.3166 44.0108 9.5 44.0108 9.5C44.0196 9.25627 44.1177 9.01448 44.3038 8.82843L47.8393 5.29289C48.2298 4.90237 48.863 4.90237 49.2535 5.29289C49.644 5.68342 49.644 6.31658 49.2535 6.70711L47.4749 8.48575C47.8956 8.51161 48.3335 8.55317 48.7716 8.61056C50.0287 8.77525 51.4066 9.08528 52.4472 9.60557C53.5789 10.1714 54.748 11.0435 55.6182 12.5664C56.4794 14.0734 57 16.134 57 19C57 19.5523 56.5523 20 56 20C55.4477 20 55 19.5523 55 19C55 16.366 54.5206 14.6766 53.8818 13.5586C53.252 12.4565 52.4211 11.8286 51.5528 11.3944C50.8045 11.0203 49.6825 10.747 48.5118 10.5936C47.9374 10.5184 47.3801 10.4756 46.8853 10.4603Z' fill='%230F172A'/%3E%3Cpath d='M14.7465 51.1716L17.1147 53.5397C16.6199 53.5244 16.0626 53.4816 15.4882 53.4064C14.3175 53.253 13.1955 52.9797 12.4472 52.6056C11.5789 52.1714 10.748 51.5435 10.1182 50.4414C9.47944 49.3234 9 47.634 9 45C9 44.4477 8.55229 44 8 44C7.44772 44 7 44.4477 7 45C7 47.866 7.52057 49.9266 8.38176 51.4336C9.25196 52.9565 10.4211 53.8286 11.5528 54.3944C12.5934 54.9147 13.9713 55.2247 15.2284 55.3894C15.6665 55.4468 16.1044 55.4884 16.5251 55.5142L14.7465 57.2929C14.356 57.6834 14.356 58.3166 14.7465 58.7071C15.137 59.0976 15.7702 59.0976 16.1607 58.7071L19.6962 55.1716C19.8823 54.9855 19.9804 54.7437 19.9892 54.5C19.9892 54.5 20.0868 53.6834 19.6963 53.2929L16.1607 49.7574C15.7702 49.3668 15.137 49.3668 14.7465 49.7574C14.356 50.1479 14.356 50.7811 14.7465 51.1716Z' fill='%230F172A'/%3E%3C/svg%3E%0A");
		}
		<?php
		$icons_css = ob_get_clean();

		wp_register_style( 'jet-engine-layout-switcher-icons', false );
		wp_enqueue_style( 'jet-engine-layout-switcher-icons' );

		wp_add_inline_style( 'jet-engine-layout-switcher-icons', $icons_css );
	}

	public function register_scripts() {
		wp_register_script(
			'jet-engine-layout-switcher',
			JET_ENGINE_LAYOUT_SWITCHER_URL . 'assets/js/layout-switcher.js',
			array( 'jquery', 'jet-engine-frontend' ),
			JET_ENGINE_LAYOUT_SWITCHER_VERSION,
			true
		);
	}

	public function register_styles() {
		wp_register_style(
			'jet-engine-layout-switcher',
			JET_ENGINE_LAYOUT_SWITCHER_URL . 'assets/css/layout-switcher.css',
			array(),
			JET_ENGINE_LAYOUT_SWITCHER_VERSION,
		);
	}

	public function enqueue_preview_scripts() {
		wp_enqueue_style( 'jet-engine-layout-switcher' );
		//wp_enqueue_script( 'jet-engine-layout-switcher' );
	}

	public function update_listing_default_settings( $settings ) {
		$settings['_id'] = '';
		return $settings;
	}

	public function update_listing_nav_widget_settings( $result, $settings ) {
		$result['_id'] = ! empty( $settings['_id'] ) ? $settings['_id'] : '';
		return $result;
	}

	public function switch_layout() {
		$widget_id = ! empty( $_REQUEST['widget_id'] ) ? $_REQUEST['widget_id'] : false;
		$layout    = ! empty( $_REQUEST['layout'] ) ? $_REQUEST['layout'] : false;
		$settings  = ! empty( $_REQUEST['settings'] ) ? $_REQUEST['settings'] : false;

		if ( empty( $widget_id ) || empty( $layout ) || empty( $settings ) ) {
			wp_send_json_error();
		}

		$cookie_val = array(
			'layout'   => $layout,
			'settings' => $settings,
		);

		setcookie(
			'jet_engine_layout_' . esc_attr( $widget_id ),
			json_encode( $cookie_val ),
			time() + MONTH_IN_SECONDS,
			COOKIEPATH ? COOKIEPATH : '/',
			COOKIE_DOMAIN,
			( false !== strstr( get_option( 'home' ), 'https:' ) && is_ssl() ),
			true
		);

		wp_send_json_success();
	}

	public function maybe_apply_layout_settings( $settings ) {

		$is_edit_mode = class_exists( 'Elementor\Plugin' ) && \Elementor\Plugin::instance()->editor->is_edit_mode();

		if ( $is_edit_mode ) {
			return $settings;
		}

		$widget_id = ! empty( $settings['_id'] ) ? $settings['_id'] : false;

		// Get the widget id on lazy load
		if ( ! $widget_id && ! empty( $_REQUEST['action'] ) && 'jet_engine_ajax' === $_REQUEST['action']
			 && ! empty( $_REQUEST['handler'] ) && 'get_listing' === $_REQUEST['handler']
			 && ! empty( $_REQUEST['element_id'] )
		) {
			$widget_id = $_REQUEST['element_id'];
		}

		if ( ! $widget_id ) {
			return $settings;
		}

		$cookie_key = 'jet_engine_layout_' . esc_attr( $widget_id );

		if ( ! isset( $_COOKIE[ $cookie_key ] ) ) {
			return $settings;
		}

		$cookie_value = isset( $_COOKIE[ $cookie_key ] ) ? json_decode( wp_unslash( $_COOKIE[ $cookie_key ] ), true ) : false;

		if ( empty( $cookie_value ) || empty( $cookie_value['settings'] ) ) {
			return $settings;
		}

		// Add query data to attributes.
		add_filter( 'jet-engine/listing/grid/add-query-data', function ( $add_query_data, $render ) use ( $widget_id ) {

			$widget_settings = $render->get_settings();

			if ( empty( $widget_settings['_id'] ) ) {
				return $add_query_data;
			}

			if ( $widget_settings['_id'] !== $widget_id ) {
				return $add_query_data;
			}

			return true;
		}, 10, 2 );

		$document = false;

		if ( class_exists( 'Elementor\Plugin' ) ) {
			$document = \Elementor\Plugin::instance()->documents->get_current();

			// Get the document on lazy load
			if ( ! $document && ! empty( $_REQUEST['action'] ) && 'jet_engine_ajax' === $_REQUEST['action']
				 && ! empty( $_REQUEST['handler'] ) && 'get_listing' === $_REQUEST['handler']
				 && ! empty( $_REQUEST['post_id'] )
			) {
				$document = \Elementor\Plugin::instance()->documents->get_doc_for_frontend( $_REQUEST['post_id'] );
			}
		}

		if ( ! $document ) {
			return $settings;
		}

		$has_relative_switcher = $this->has_relative_switcher_on_page( $document->get_elements_data(), $widget_id );

		if ( ! $has_relative_switcher ) {
			return $settings;
		}

		$initial_listing_id = (int) $settings['lisitng_id'];
		$layout_listing_id  = (int) $cookie_value['settings']['lisitng_id'];

		// Set initial listing before receiving query.
		if ( $initial_listing_id !== $layout_listing_id ) {
			add_filter( 'jet-engine/listing/grid/source', function ( $source, $widget_settings ) use ( $initial_listing_id, $widget_id ) {

				if ( empty( $widget_settings['_id'] ) ) {
					return $source;
				}

				if ( $widget_settings['_id'] !== $widget_id ) {
					return $source;
				}

				jet_engine()->listings->data->set_listing_by_id( $initial_listing_id );
				return $source;
			}, 10, 2 );
		}

		return array_merge( $settings, $cookie_value['settings'] );
	}

	public function has_relative_switcher_on_page( $elements, $grid_widget_id ) {

		foreach ( $elements as $element ) {

			if ( ! empty( $element['widgetType'] )
				 && 'jet-engine-layout-switcher' === $element['widgetType']
				 && ! empty( $element['settings']['widget_id'] )
				 && $grid_widget_id === $element['settings']['widget_id']
			) {
				return true;
			}

			if ( ! empty( $element['elements'] ) ) {
				$result = $this->has_relative_switcher_on_page( $element['elements'], $grid_widget_id );

				if ( $result ) {
					return true;
				}
			}
		}

		return false;
	}

	public function set_filtered_query_on_switch_layout( $query ) {

		if ( ! jet_engine()->listings->is_listing_ajax() ) {
			return;
		}

		if ( empty( $_REQUEST['switch_layout'] ) || empty( $_REQUEST['listing_query_id'] ) ) {
			return;
		}

		if ( ! function_exists( 'jet_smart_filters' ) || empty( $_REQUEST['filtered_query'] ) ) {
			return;
		}

		$l_query_id = intval( $_REQUEST['listing_query_id'] );
		$query_id   = intval( $query->id );

		if ( $l_query_id !== $query_id ) {
			return;
		}

		$filtered_query = jet_smart_filters()->query->get_query_from_request( $_REQUEST['filtered_query'] );

		if ( ! empty( $filtered_query ) ) {
			foreach ( $filtered_query as $prop => $value ) {
				$query->set_filtered_prop( $prop, $value );
			}
		}
	}

	public function update_query_on_switch_layout( $args, $render, $settings ) {

		if ( ! jet_engine()->listings->is_listing_ajax() ) {
			return $args;
		}

		if ( empty( $_REQUEST['switch_layout'] ) ) {
			return $args;
		}

		if ( empty( $_REQUEST['query'] ) || empty( $_REQUEST['widget_settings'] ) ) {
			return $args;
		}

		if ( ! isset( $settings['_id'] ) || ! isset( $_REQUEST['widget_settings']['_id'] ) ) {
			return $args;
		}

		if ( $settings['_id'] !== $_REQUEST['widget_settings']['_id'] ) {
			return $args;
		}

		$args = wp_unslash( $_REQUEST['query'] );

		return $args;
	}

}

Plugin::instance();
