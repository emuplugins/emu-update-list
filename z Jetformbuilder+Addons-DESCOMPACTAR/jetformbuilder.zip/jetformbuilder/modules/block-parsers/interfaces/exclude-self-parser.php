<?php


namespace JFB_Modules\Block_Parsers\Interfaces;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

interface Exclude_Self_Parser {

}
