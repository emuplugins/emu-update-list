<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

return array(
	array(
		'label' => __( 'January', 'jet-form-builder' ),
		'value' => 'Jan',
	),
	array(
		'label' => __( 'February', 'jet-form-builder' ),
		'value' => 'Feb',
	),
	array(
		'label' => __( 'March', 'jet-form-builder' ),
		'value' => 'Mar',
	),
	array(
		'label' => __( 'April', 'jet-form-builder' ),
		'value' => 'Apr',
	),
	array(
		'label' => __( 'May', 'jet-form-builder' ),
		'value' => 'May',
	),
	array(
		'label' => __( 'June', 'jet-form-builder' ),
		'value' => 'Jun',
	),
	array(
		'label' => __( 'July', 'jet-form-builder' ),
		'value' => 'Jul',
	),
	array(
		'label' => __( 'August', 'jet-form-builder' ),
		'value' => 'Aug',
	),
	array(
		'label' => __( 'September', 'jet-form-builder' ),
		'value' => 'Sep',
	),
	array(
		'label' => __( 'October', 'jet-form-builder' ),
		'value' => 'Oct',
	),
	array(
		'label' => __( 'November', 'jet-form-builder' ),
		'value' => 'Nov',
	),
	array(
		'label' => __( 'December', 'jet-form-builder' ),
		'value' => 'Dec',
	),
);
