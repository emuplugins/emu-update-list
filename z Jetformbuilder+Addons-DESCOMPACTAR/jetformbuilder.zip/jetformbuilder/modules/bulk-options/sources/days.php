<?php


return array(
	array(
		'value' => 'Sun',
		'label' => __( 'Sunday', 'jet-form-builder' ),
	),
	array(
		'value' => 'Mon',
		'label' => __( 'Monday', 'jet-form-builder' ),
	),
	array(
		'value' => 'Tue',
		'label' => __( 'Tuesday', 'jet-form-builder' ),
	),
	array(
		'value' => 'Wed',
		'label' => __( 'Wednesday', 'jet-form-builder' ),
	),
	array(
		'value' => 'Thu',
		'label' => __( 'Thursday', 'jet-form-builder' ),
	),
	array(
		'value' => 'Fri',
		'label' => __( 'Friday', 'jet-form-builder' ),
	),
	array(
		'value' => 'Sat',
		'label' => __( 'Saturday', 'jet-form-builder' ),
	),
);
