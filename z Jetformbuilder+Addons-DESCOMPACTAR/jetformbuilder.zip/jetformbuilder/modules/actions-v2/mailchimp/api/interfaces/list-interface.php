<?php

namespace JFB_Modules\Actions_V2\Mailchimp\Api\interfaces;

interface List_Interface {

	public function set_list_id( string $list_id );

}
