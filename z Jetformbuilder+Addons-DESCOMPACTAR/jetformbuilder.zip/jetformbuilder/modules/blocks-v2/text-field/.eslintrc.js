module.exports = {
	extends: [
		'../../../.eslintrc.js',
	],
	globals: {
		JFBTextFieldConfig: 'readonly',
	},
};