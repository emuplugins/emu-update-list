<?php


namespace Jet_Form_Builder\Gateways;

use JFB_Modules\Gateways;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

abstract class Base_Gateway_Action extends Gateways\Base_Gateway_Action {

}
