<?php
/**
 * Required for
 * \Jet_FB_Stripe_Gateway\Compatibility\Jet_Form_Builder\Manager
 */

namespace Jet_Form_Builder\Gateways;

use JFB_Modules\Gateways\Module;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Gateway_Manager extends Module {

}
