<?php
/**
 * Required for
 * \Jet_FB_Paypal\Pages\MetaBoxes\PaymentDetailsBox
 */

namespace Jet_Form_Builder\Gateways\Meta_Boxes;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

use JFB_Modules\Gateways\Meta_Boxes\Payment_Details_Box as Base;

class Payment_Details_Box extends Base {

}
