<?php


namespace JFB_Modules\Gateways\Actions_Abstract;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

interface Action_Application_Raw_Body_It {

}
