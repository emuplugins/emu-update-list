<?php
/**
 * Plugin Name: JetFormBuilder MailerLite Action
 * Plugin URI:  https://jetformbuilder.com/addons/mailerlite-action/
 * Description: A top-notch addon to bring your email marketing to the next level.
 * Version:     1.0.4
 * Author:      Crocoblock
 * Author URI:  https://crocoblock.com/
 * Text Domain: jet-form-builder-mailerlite-action
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'JET_FB_MAILERLITE_ACTION_VERSION', '1.0.4' );

define( 'JET_FB_MAILERLITE_ACTION__FILE__', __FILE__ );
define( 'JET_FB_MAILERLITE_ACTION_PLUGIN_BASE', plugin_basename( __FILE__ ) );
define( 'JET_FB_MAILERLITE_ACTION_PATH', plugin_dir_path( __FILE__ ) );
define( 'JET_FB_MAILERLITE_ACTION_URL', plugins_url( '/', __FILE__ ) );

require JET_FB_MAILERLITE_ACTION_PATH . 'vendor/autoload.php';

add_action( 'plugins_loaded', function () {

	if ( ! version_compare( PHP_VERSION, '7.0.0', '>=' ) ) {
		add_action( 'admin_notices', function () {
			$class   = 'notice notice-error';
			$message = __(
				'<b>Error:</b> <b>JetFormBuilder MailerLite Action</b> plugin requires a PHP version ">= 7.0"',
				'jet-form-builder-mailerlite-action'
			);
			printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), wp_kses_post( $message ) );
		} );

		return;
	}

	require JET_FB_MAILERLITE_ACTION_PATH . 'includes/plugin.php';

}, 100 );

