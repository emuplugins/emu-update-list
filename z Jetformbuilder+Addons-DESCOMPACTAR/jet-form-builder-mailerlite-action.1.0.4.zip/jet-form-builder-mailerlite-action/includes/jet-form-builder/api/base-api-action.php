<?php

namespace Jet_FB_MailerLite\Jet_Form_Builder\Api;

use Jet_Form_Builder\Exceptions\Gateway_Exception;
use JFB_Modules\Gateways\Base_Gateway_Action;

class Base_Api_Action extends Base_Gateway_Action {

	public function base_url(): string {
		return 'https://connect.mailerlite.com/api/';
	}

	public function get_request_args(): array {
		return array_merge(
			parent::get_request_args(),
			array(
				'user-agent' => sprintf(
					'JetFormBuilder/%s; %s',
					jet_form_builder()->get_version(),
					get_bloginfo( 'name' )
				),
			)
		);
	}

	public function send_request() {
		parent::send_request();

		$response = $this->get_response_body();

		if ( isset( $response['errors'] ) ) {
			throw new Gateway_Exception(
				sprintf(
					'Error on request /%s',
					$this->action_endpoint() // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
				),
				$response // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
			);
		}

		if ( isset( $response['message'] ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
			throw new Gateway_Exception( $response['message'], $response );
		}
	}

	public function action_headers() {
		return array(
			'X-Version'    => '2023-02-16',
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
		);
	}

}
