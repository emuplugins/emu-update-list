<?php

namespace Jet_FB_MailerLite\Jet_Form_Builder\Api;

class Get_Groups_Api extends Base_Api_Action {

	protected $method = 'GET';

	public function action_endpoint() {
		return 'groups';
	}

	/**
	 * @return \Generator
	 */
	public function generate_groups(): \Generator {
		$response = $this->get_response_body();

		foreach ( $response['data'] as $group ) {
			yield array(
				'value' => $group['id'],
				'label' => $group['name'],
			);
		}
	}

}
