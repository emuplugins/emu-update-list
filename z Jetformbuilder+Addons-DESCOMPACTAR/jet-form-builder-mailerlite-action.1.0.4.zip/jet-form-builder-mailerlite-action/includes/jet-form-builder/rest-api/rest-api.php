<?php

namespace Jet_FB_MailerLite\Jet_Form_Builder\Rest_Api;

use Jet_Form_Builder\Admin\Tabs_Handlers\Base_Handler;

class Rest_Api {

	public function init_hooks() {
		if ( ! class_exists( 'JFB_Components\Rest_Api\Route' ) ) {
			return;
		}
		add_action( 'rest_api_init', array( $this, 'rest_api_init' ) );
	}

	public function rest_api_init() {
		$route = new Mailerlite\Mailerlite_Route();
		$route->register();

		register_setting(
			trim( Base_Handler::PREFIX, '_' ),
			Base_Handler::PREFIX . 'mailer-lite-tab',
			array(
				'type'         => 'string',
				'show_in_rest' => true,
				'default'      => '{}',
			)
		);
	}

}
