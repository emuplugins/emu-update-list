<?php

namespace Jet_FB_MailerLite\Jet_Form_Builder\Rest_Api\Mailerlite;

use JFB_Components\Rest_Api\Route;

class Mailerlite_Route extends Route {

	public function __construct() {
		$this->set_namespace( 'jet-form-builder/v1' );
		$this->set_route( 'mailerlite' );
		$this->add_endpoint( new Mailerlite_Endpoint() );
	}

}
