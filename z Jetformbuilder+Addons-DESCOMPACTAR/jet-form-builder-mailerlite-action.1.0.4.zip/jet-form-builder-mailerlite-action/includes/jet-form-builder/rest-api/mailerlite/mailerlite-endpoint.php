<?php

namespace Jet_FB_MailerLite\Jet_Form_Builder\Rest_Api\Mailerlite;

use Jet_FB_MailerLite\Jet_Form_Builder\Api\Get_Fields_Api;
use Jet_FB_MailerLite\Jet_Form_Builder\Api\Get_Groups_Api;
use Jet_Form_Builder\Exceptions\Gateway_Exception;
use JFB_Components\Rest_Api\Interfaces\Endpoint_Interface;
use Jet_FB_MailerLite\Jet_Form_Builder\Api\Action_Factory;

class Mailerlite_Endpoint implements Endpoint_Interface {

	/**
	 * @var Action_Factory
	 */
	private $factory;

	public function get_method(): string {
		return \WP_REST_Server::READABLE;
	}

	public function has_permission(): bool {
		return current_user_can( 'manage_options' );
	}

	public function get_args(): array {
		return array(
			'apiKey' => array(
				'type'     => 'string',
				'required' => true,
			),
		);
	}

	public function process( \WP_REST_Request $request ): \WP_REST_Response {
		$factory = new Action_Factory();
		$factory->set_api_key( $request['apiKey'] ?? '' );

		try {
			/** @var Get_Groups_Api $get_groups */
			$get_groups = $factory->create( Get_Groups_Api::class );
			$get_groups->send_request();

			$groups = iterator_to_array( $get_groups->generate_groups() );
		} catch ( Gateway_Exception $exception ) {
			return new \WP_REST_Response(
				array(
					'code'    => 'not_found_groups',
					'message' => $exception->getMessage(),
				),
				404
			);
		}

		try {
			/** @var Get_Fields_Api $get_fields */
			$get_fields = $factory->create( Get_Fields_Api::class );
			$get_fields->send_request();

			$fields = array_values(
				iterator_to_array( $get_fields->generate_fields() )
			);

		} catch ( Gateway_Exception $exception ) {
			return new \WP_REST_Response(
				array(
					'code'    => 'not_found_fields',
					'message' => $exception->getMessage(),
				),
				404
			);
		}

		return new \WP_REST_Response(
			array(
				'groups' => $groups,
				'fields' => $fields,
			)
		);
	}
}
