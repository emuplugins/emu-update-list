<?php


namespace Jet_FB_MailerLite\Jet_Form_Builder\Actions;


use Jet_FB_MailerLite\Handler_New;
use Jet_Form_Builder\Actions\Action_Handler;
use Jet_Form_Builder\Actions\Types\Base;
use Jet_Form_Builder\Exceptions\Action_Exception;

class Action_New extends Base {

	public $option_name = 'mailer-lite-tab';

	public function get_name() {
		return __( 'MailerLite', 'jet-form-builder-mailerlite-action' );
	}

	public function get_id() {
		return 'mailer_lite_new';
	}

	/**
	 * @param array $request
	 * @param Action_Handler $handler
	 *
	 * @return mixed|void
	 * @throws Action_Exception
	 */
	public function do_action( array $request, Action_Handler $handler ) {
		$settings = array_merge(
			$this->settings,
			$this->global_settings(
				array( 'api_key' => '' )
			)
		);

		if ( empty( $settings['api_key'] ) || empty( $settings['group_id'] ) ) {
			throw new Action_Exception( 'invalid_api_key' );
		}

		$handler  = Handler_New::instance()->set_arg( 'api_key', $settings['api_key'] );
		$response = $handler->create_subscriber( $settings, $request );

		if ( isset( $response['errors'] ) ) {
			throw new Action_Exception( $response['message'], $response );
		}
	}
}