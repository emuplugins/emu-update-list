<?php


namespace Jet_FB_MailerLite;


use Jet_Form_Builder\Exceptions\Action_Exception;
use JetMailerLiteCore\BaseHandler;
use JetMailerLiteCore\Common\Tools;
use JetMailerLiteCore\Exceptions\ApiHandlerException;
use JetMailerLiteCore\Exceptions\BaseHandlerException;

class Handler_New extends BaseHandler {

	public static $instance;

	public static function instance(): Handler_New {
		if ( is_null( self::$instance ) ) {
			self::$instance = new static();
		}

		return self::$instance;
	}

	protected $api_base_url = 'https://connect.mailerlite.com/';

	public function ajax_action(): string {
		return 'jet_form_builder_get_mailerlite_new_data';
	}

	public function get_api_request_args() {
		return array(
			'headers'    => array(
				'Authorization' => sprintf( 'Bearer %s', $this->request_args['api_key'] ?? '' ),
				'X-Version'     => '2023-02-16',
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json'
			),
			'user-agent' => sprintf(
				'JetFormBuilder/%s; %s',
				jet_form_builder()->get_version(),
				get_bloginfo( 'name' )
			),
		);
	}

	/**
	 * @throws Action_Exception
	 */
	public function create_subscriber( array $settings, array $request ) {
		$fields_map = $this->prepare_request( $settings, $request );

		$request_args = array(
			'method' => 'POST',
			'body'   => json_encode( $fields_map ),
		);

		return $this->request( 'api/subscribers', $request_args );
	}

	/**
	 * @param $settings
	 * @param array $request
	 *
	 * @return array
	 * @throws Action_Exception
	 */
	public function prepare_request( $settings, array $request ): array {
		$response = array();

		if ( empty( $settings['fields_map'] ) ) {
			throw new Action_Exception( 'internal_error', $settings );
		}

		foreach ( $settings['fields_map'] as $param => $field ) {

			if ( empty( $field ) || empty( $request[ $field ] ) ) {
				continue;
			}
			if ( in_array( $param, array( 'email' ) ) ) {
				$response[ $param ] = $request[ $field ];
			} else {
				$response['fields'][ $param ] = $request[ $field ];
			}
		}

		$group_id = $settings['group_id'] ?? 0;

		if ( $group_id ) {
			$response['groups'] = array( $group_id );
		}

		return $response;
	}

	/**
	 * @return array
	 * @throws ApiHandlerException
	 */
	public function get_all_data() {
		$groups = $this->get_request(
			'api/groups'
		);
		$fields = $this->get_request(
			'api/fields'
		);

		$groups = Tools::with_placeholder(
			Tools::prepare_list_for_js( $groups['data'], 'id', 'name' )
		);
		$fields = $this->prepare_list( $fields['data'], 'name' );

		$fields = array_merge(
			array(
				'email' => array(
					'label'    => __( 'Email', 'jet-form-builder' ),
					'required' => true,
				)
			),
			$fields
		);

		return array(
			'fields' => $fields,
			'groups' => $groups
		);
	}

	/**
	 * @param $endpoint
	 * @param array $args
	 *
	 * @return array|false|mixed
	 * @throws ApiHandlerException
	 */
	public function get_request( $endpoint, array $args = array() ) {
		$response = $this->request( $endpoint, $args );

		if ( isset( $response['errors'] ) ) {
			throw new ApiHandlerException( "Error on request /$endpoint", '', $response );
		}

		if ( isset( $response['message'] ) ) {
			throw new ApiHandlerException( $response['message'], '', $response );
		}

		if ( is_null( $response ) ) {
			throw new ApiHandlerException( "Body is null on /$endpoint", '', $this->request_args );
		}

		return $response;
	}

	private function prepare_list( $source, $label_name, $key_name = 'key' ) {
		$result = array();

		foreach ( $source as $item ) {
			$result[ $item[ $key_name ] ] = array( 'label' => $item[ $label_name ] );
		}

		return $result;
	}
}