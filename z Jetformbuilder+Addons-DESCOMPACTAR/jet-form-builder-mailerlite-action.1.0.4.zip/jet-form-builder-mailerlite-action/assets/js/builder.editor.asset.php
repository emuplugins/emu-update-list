<?php return array('dependencies' => array('react'), 'version' => '1bfbcd8dfeda3ac4f6d1');
