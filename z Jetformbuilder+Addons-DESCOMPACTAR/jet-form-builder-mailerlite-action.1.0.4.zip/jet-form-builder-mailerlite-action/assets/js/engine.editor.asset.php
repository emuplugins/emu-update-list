<?php return array('dependencies' => array(), 'version' => '280e5e2c842a054fc7fd');
