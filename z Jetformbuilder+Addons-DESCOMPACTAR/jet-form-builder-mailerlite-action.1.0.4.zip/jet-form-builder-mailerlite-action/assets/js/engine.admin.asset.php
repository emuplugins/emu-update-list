<?php return array('dependencies' => array(), 'version' => 'b3b2c05fe1e1d12cb821');
