<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-components', 'wp-data', 'wp-i18n', 'wp-primitives', 'wp-url'), 'version' => '778056e4b796ff6639cb');
