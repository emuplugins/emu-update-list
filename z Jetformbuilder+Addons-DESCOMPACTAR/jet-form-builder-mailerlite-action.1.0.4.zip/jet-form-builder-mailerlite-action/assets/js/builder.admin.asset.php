<?php return array('dependencies' => array(), 'version' => 'daf3c32a38c81ca4f61c');
