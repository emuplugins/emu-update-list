<?php


namespace Jet_FB_Schedule_Forms\Jet_Form_Builder;


use Jet_FB_Schedule_Forms\Schedule_Form;
use JetScheduleFormsCore\JetFormBuilder\PreventFormSubmit;

class Prevent_Form_Submit extends PreventFormSubmit {

	public function prevent_process_ajax_form( $handler ) {
		Schedule_Form::get_jfb_settings( $handler->form_id );

		$type = Schedule_Form::get_schedule_type();

		if ( ! $type ) {
			return;
		}
		//$message = Schedule_Form::get_message( $type );

		$handler->send_response( array(
			'status' => 'failed',
		) );
	}

	public function prevent_process_reload_form( $handler ) {
		Schedule_Form::get_jfb_settings( $handler->form_id );

		$type = Schedule_Form::get_schedule_type();

		if ( ! $type ) {
			return;
		}

		$handler->send_response( array(
			'status' => 'failed',
		) );
	}

}