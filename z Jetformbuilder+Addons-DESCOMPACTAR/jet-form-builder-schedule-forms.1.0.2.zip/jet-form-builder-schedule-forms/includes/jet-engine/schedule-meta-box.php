<?php


namespace Jet_FB_Schedule_Forms\Jet_Engine;


use Jet_FB_Schedule_Forms\Plugin;
use Jet_FB_Schedule_Forms\Schedule_Form;
use JetScheduleFormsCore\JetEngine\RegisterFormMetaBox;

class Schedule_Meta_Box extends RegisterFormMetaBox {

	public static $instance = null;

	public function get_id() {
		return Schedule_Form::PLUGIN_META_KEY;
	}

	public function get_title() {
		return __( 'Form Schedule', 'jet-form-builder-schedule-forms' );
	}

	public function get_fields() {
		ob_start();
		include Plugin::instance()->get_template_path( 'meta-box' );
		$content = ob_get_clean();

		return array(
			$this->get_id() => array(
				'type' => 'html',
				'html' => $content,
			)
		);
	}

	public function register_assets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/dist/engine.bundle.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);

		wp_localize_script( Plugin::instance()->slug, 'JetScheduleForms', array(
			'schedule' => Schedule_Form::get_form_schedule(),
		) );
	}

	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder Schedule Forms</b> needs <b>JetEngine</b> update.',
			'jet-form-builder-schedule-forms'
		) );
	}

	public function on_base_need_install() {
	}
}