<?php

namespace JFB_PDF\Vendor\Auryn;

class InjectorException extends \Exception
{
}
