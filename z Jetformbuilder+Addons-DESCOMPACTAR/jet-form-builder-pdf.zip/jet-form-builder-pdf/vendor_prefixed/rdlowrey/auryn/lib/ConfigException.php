<?php

namespace JFB_PDF\Vendor\Auryn;

class ConfigException extends InjectorException
{
}
