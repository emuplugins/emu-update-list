# JetFormBuilder Select Autocomplete
Premium Addon for JetFormBuilder &amp; JetEngine Forms

# ChangeLog

## 1.0.7
* ADD: Custom messages

## 1.0.6
* UPD: Improve performance on ajax loading

## 1.0.5
* ADD: php-filter `'jet-forms/select-autocomplete/filter-callback`
* UPD: JetFormBuilder 3.0 compatibility

## 1.0.4
* FIX: Appearance on frontend

## 1.0.3
* Tweak: Removed unnecessary hook

## 1.0.2
* Tweak: add license manager

## 1.0.1
* FIX: allowed guests to use autocomplete
* Tweak: added js hook `jet.fb.select_autocomplete.options`

## 1.0.0
* Initial release
