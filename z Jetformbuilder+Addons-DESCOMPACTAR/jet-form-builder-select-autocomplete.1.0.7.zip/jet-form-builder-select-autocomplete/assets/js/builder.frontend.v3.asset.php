<?php return array('dependencies' => array('wp-hooks'), 'version' => 'a97f0a075d928ae80dde');
