<?php return array('dependencies' => array('wp-hooks'), 'version' => 'bccf399063398dd7e717');
