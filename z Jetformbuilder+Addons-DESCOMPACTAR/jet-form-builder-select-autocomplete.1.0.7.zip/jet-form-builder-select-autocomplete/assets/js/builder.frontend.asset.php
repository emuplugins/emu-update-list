<?php return array('dependencies' => array('wp-hooks'), 'version' => 'cd9ac808400ede617614');
