<?php

namespace JFB\SelectAutocomplete\Vendor\Auryn;

class ConfigException extends InjectorException
{
}
