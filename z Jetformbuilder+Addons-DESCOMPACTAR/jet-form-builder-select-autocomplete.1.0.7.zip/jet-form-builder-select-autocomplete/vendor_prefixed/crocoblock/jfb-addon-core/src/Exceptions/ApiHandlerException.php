<?php

namespace JFB\SelectAutocomplete\Vendor\JFBCore\Exceptions;

class ApiHandlerException extends BaseHandlerException
{
}
