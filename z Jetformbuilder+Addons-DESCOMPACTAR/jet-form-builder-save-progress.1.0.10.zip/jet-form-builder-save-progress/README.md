# JetFormBuilder Save Progress
Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.0.10
* FIX: Save form Progress duplicates repeater

## 1.0.9
* FIX: Compatibility with the Repeater field
* FIX: Page reload submit type

## 1.0.8
* UPD: JetFormBuilder 3.0 compatibility
* FIX: Radio field loading

## 1.0.7
* FIX: Multistep compatibility

## 1.0.6
* FIX: Multistep progress with required fields in Conditional block

## 1.0.5
* FIX: Double initialization in JetForm Elementor widget 
* FIX: Preview for not-images

## 1.0.4
* Tweak: Removed unnecessary hook

## 1.0.3
* Tweak: add license manager

## 1.0.2
* ADD: Ability to clear local storage on successful form submission

## 1.0.1
* FIX: Get form id on change value

## 1.0.0
* Initial release