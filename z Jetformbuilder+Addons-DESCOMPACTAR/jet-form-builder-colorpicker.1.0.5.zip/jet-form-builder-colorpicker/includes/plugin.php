<?php

namespace Jet_FB_ColorPicker;


use Jet_FB_ColorPicker\JetEngine\Fields\ManagerFields;
use Jet_FB_ColorPicker\JetFormBuilder\ColorPickerModifier;
use JetColorPickerCore\LicenceProxy;

if ( ! defined( 'WPINC' ) ) {
	die();
}

class Plugin {
	/**
	 * Instance.
	 *
	 * Holds the plugin instance.
	 *
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 * @var Plugin
	 */
	public static $instance = null;

	public $slug = 'jet-form-builder-colorpicker';

	public function __construct() {
		ColorPickerModifier::register();

		ManagerFields::register();

		LicenceProxy::register();
	}

	public function get_version() {
		return JET_FB_COLOR_PICKER_VERSION;
	}

	public function plugin_url( $path ) {
		return JET_FB_COLOR_PICKER_URL . $path;
	}

	public function plugin_dir( $path ) {
		return JET_FB_COLOR_PICKER_PATH . $path;
	}

	public function get_template_path( $template ) {
		$path = JET_FB_COLOR_PICKER_PATH . 'templates' . DIRECTORY_SEPARATOR;

		return ( $path . $template );
	}


	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @return Plugin An instance of the class.
	 * @since 1.0.0
	 * @access public
	 * @static
	 *
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

}

Plugin::instance();