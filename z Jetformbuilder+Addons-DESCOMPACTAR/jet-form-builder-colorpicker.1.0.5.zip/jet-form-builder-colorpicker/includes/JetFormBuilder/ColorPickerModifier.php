<?php


namespace Jet_FB_ColorPicker\JetFormBuilder;

use Jet_FB_ColorPicker\ColorPicker;
use Jet_FB_ColorPicker\Plugin;
use JetColorPickerCore\JetFormBuilder\BaseFieldModifier;

class ColorPickerModifier extends BaseFieldModifier {

	public function type(): string {
		return 'color-picker-field';
	}

	public function editorAssets() {
		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/dist/builder.editor.js' ),
			array(),
			Plugin::instance()->get_version(),
			true
		);
	}

	public function onRender(): array {
		$args     = $this->getArgs();
		$settings = ColorPicker::prepare_settings( $args, $this );

		if ( isset( $settings['use_advanced'] ) && ! $settings['use_advanced'] ) {
			return $args;
		}
		$args['field_type'] = 'text';

		ColorPicker::enqueue();

		$this->getClass()->add_attribute( 'class', 'jet-fb-color-picker-advanced' );
		$this->getClass()->add_attribute( 'data-fb-settings', esc_attr( wp_json_encode( $settings ) ) );

		return $args;
	}

	public function on_base_need_update() {
		$this->add_admin_notice(
			'warning',
			__(
				'<b>Warning</b>: <b>JetFormBuilder Advanced Color Picker</b> needs <b>JetFormBuilder</b> update.',
				'jet-form-builder-colorpicker'
			)
		);
	}

	public function on_base_need_install() {
	}
}
