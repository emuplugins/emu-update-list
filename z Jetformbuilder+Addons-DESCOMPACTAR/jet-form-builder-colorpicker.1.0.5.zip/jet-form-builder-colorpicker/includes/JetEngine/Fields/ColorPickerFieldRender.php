<?php


namespace Jet_FB_ColorPicker\JetEngine\Fields;

use Jet_FB_ColorPicker\ColorPicker;
use JetColorPickerCore\JetEngine\RenderField;

class ColorPickerFieldRender {

	use RenderField;

	public function get_name() {
		return 'color_picker_field';
	}

	public function attributes_values() {
		$settings = ColorPicker::prepare_settings( $this->args, $this );

		$args = array(
			'class' => array( 'jet-form-builder__color-picker-field' ),
			'type'  => 'color',
		);

		if ( ! isset( $settings['use_advanced'] ) || ! $settings['use_advanced'] ) {
			return $args;
		}

		ColorPicker::enqueue();

		$args['type']             = 'text';
		$args['class'][]          = 'jet-fb-color-picker-advanced';
		$args['data-fb-settings'] = esc_attr( wp_json_encode( $settings ) );

		return $args;
	}

	public function render_field( $attrs_string ) {
		return "<input $attrs_string />";
	}

}
