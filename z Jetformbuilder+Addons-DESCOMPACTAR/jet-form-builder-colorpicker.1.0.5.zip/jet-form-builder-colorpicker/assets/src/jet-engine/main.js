import FieldComponent from "./FieldComponent.vue";

const { addFilter } = wp.hooks;

addFilter( 'jet.engine.register.fields', 'jet-engine', fields => {
	fields.push( FieldComponent );

	return fields;
} );
