<?php
/**
 * Plugin Name: JetFormBuilder Moosend Action
 * Plugin URI: https://jetformbuilder.com/addons/moosend/
 * Description: A form extension to effectively manage subscribers and automate email marketing.
 * Version: 1.0.3
 * Author: Crocoblock
 * Author URI: https://crocoblock.com/
 * Text Domain: jet-form-builder-moosend-action
 * License: GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 * Requires PHP: 7.2
 * Requires at least: 6.0
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'JET_FB_MOOSEND_ACTION_VERSION', '1.0.3' );

define( 'JET_FB_MOOSEND_ACTION__FILE__', __FILE__ );
define( 'JET_FB_MOOSEND_ACTION_PLUGIN_BASE', plugin_basename( __FILE__ ) );
define( 'JET_FB_MOOSEND_ACTION_PATH', plugin_dir_path( __FILE__ ) );
define( 'JET_FB_MOOSEND_ACTION_URL', plugins_url( '/', __FILE__ ) );

require __DIR__ . '/includes/load.php';
