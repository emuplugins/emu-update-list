<?php


namespace JFB\Moosend\JetEngine\Tabs;

use Jet_Engine\Modules\Forms\Tabs\Base_Form_Tab;
use JFB\Moosend\ActionTabTrait;
use JFB\Moosend\Plugin;


class ActionTab extends Base_Form_Tab {

	use ActionTabTrait;

	public function render_assets() {
		$script_asset = require_once JET_FB_MOOSEND_ACTION_PATH . 'assets/js/engine.admin.asset.php';

		wp_enqueue_script(
			Plugin::SLUG . '-' . $this->slug(),
			JET_FB_MOOSEND_ACTION_URL . 'assets/js/engine.admin.js',
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}
}
