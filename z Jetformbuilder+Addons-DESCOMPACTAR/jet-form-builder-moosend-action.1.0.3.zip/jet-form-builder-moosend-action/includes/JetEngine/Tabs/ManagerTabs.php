<?php


namespace JFB\Moosend\JetEngine\Tabs;


use JFB\Moosend\Vendor\JFBCore\JetEngine\RegisterFormTabs;

class ManagerTabs {

	use RegisterFormTabs;

	public function tabs(): array {
		return array(
			new ActionTab()
		);
	}

	public function plugin_version_compare() {
		return '2.8.3';
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}

}