<?php


namespace JFB\Moosend\JetEngine\Notifications;


use JFB\Moosend\BaseAction;
use JFB\Moosend\Plugin;
use JFB\Moosend\Vendor\JFBCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use BaseAction;

}