<?php


namespace JFB\Moosend\JetFormBuilder\Actions;

use JFB\Moosend\Plugin;
use JFB\Moosend\Vendor\JFBCore\JetFormBuilder\ActionsManager;

class Manager extends ActionsManager {

	/**
	 * Supported only >= 3.4.0 JetFormBuilder
	 *
	 * @return bool
	 */
	public function can_init(): bool {
		return class_exists( '\JFB_Modules\Actions_V2\Module' );
	}

	public function register_controller( \Jet_Form_Builder\Actions\Manager $manager ) {
		$manager->register_action_type( new Action() );
	}

	/**
	 * @return void
	 */
	public function before_init_editor_assets() {
		$script_asset = require_once JET_FB_MOOSEND_ACTION_PATH . 'assets/js/builder.editor.asset.php';

		wp_enqueue_script(
			Plugin::SLUG,
			JET_FB_MOOSEND_ACTION_URL . 'assets/js/builder.editor.js',
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice(
			'warning',
			__(
				'<b>Warning</b>: <b>JetFormBuilder Moosend Action</b> needs <b>JetFormBuilder</b> update.',
				'jet-form-builder-moosend-action'
			)
		);
	}

	public function on_base_need_install() {
	}
}
