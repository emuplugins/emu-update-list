<?php

namespace JFB\Moosend\JetFormBuilder\Actions;

use Jet_Form_Builder\Actions\Action_Handler;
use Jet_Form_Builder\Actions\Types\Base;
use Jet_Form_Builder\Admin\Tabs_Handlers\Tab_Handler_Manager;
use Jet_Form_Builder\Exceptions\Action_Exception;
use Jet_Form_Builder\Exceptions\Gateway_Exception;
use JFB\Moosend\JetFormBuilder\API\ActionFactory;
use JFB\Moosend\JetFormBuilder\API\SubscribeContactAPI;
use JFB\Moosend\Vendor\Auryn\InjectionException;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define Base_Type class
 */
class Action extends Base {

	public function get_name() {
		return __( 'Moosend', 'jet-form-builder-moosend-action' );
	}

	public function get_id() {
		return 'moosend';
	}


	/**
	 * @param array $request
	 * @param Action_Handler $handler
	 *
	 * @return void
	 * @throws InjectionException|Action_Exception
	 */
	public function do_action( array $request, Action_Handler $handler ) {
		if ( empty( $this->settings['mailing_list'] ) ) {
			throw new Action_Exception( 'internal_error' );
		}

		/** @noinspection PhpUnhandledExceptionInspection */
		/** @var ActionFactory $factory */
		$factory = jet_fb_moosend_injector()->make( ActionFactory::class );
		$factory->set_api_key( $this->get_api_key() );
		$factory->set_mailing_list( $this->settings['mailing_list'] );

		$fields_map = $this->prepare_fields_map();

		/** @var SubscribeContactAPI $subscribe */
		$subscribe = $factory->create( SubscribeContactAPI::class );
		$subscribe->set_fields_map( $fields_map );

		try {
			$subscribe->send_request();
		} catch ( Gateway_Exception $exception ) {
			throw new Action_Exception( esc_html( $exception->getMessage() ) );
		}
	}

	/**
	 * @return array
	 * @throws Action_Exception
	 */
	private function prepare_fields_map(): array {
		$response = array();

		if ( empty( $this->settings['fields_map'] ) ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
			throw new Action_Exception( 'internal_error' );
		}

		if ( ! empty( $this->settings['double_opt_in'] ) ) {
			$response['HasExternalDoubleOptIn'] = true;
		}

		foreach ( $this->settings['fields_map'] as $param => $field ) {
			if ( ! jet_fb_context()->get_value( $field ) ) {
				continue;
			}
			if ( in_array( $param, array( 'Email', 'Name' ), true ) ) {
				$response[ $param ] = jet_fb_context()->get_value( $field );
			} else {
				$value = jet_fb_context()->get_value( $field );

				$response['CustomFields'][] = "$param={$value}";
			}
		}

		return $response;
	}

	private function get_api_key(): string {
		if ( empty( $this->settings['use_global'] ) ) {
			return (string) ( $this->settings['api_key'] ?? '' );
		}

		$options = Tab_Handler_Manager::get_options( 'moosend' );

		return (string) ( $options['api_key'] ?? '' );
	}
}
