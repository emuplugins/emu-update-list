<?php

namespace JFB\Moosend\JetFormBuilder\API;

use Jet_Form_Builder\Exceptions\Gateway_Exception;

class GetListsAPI extends APIAction {

	protected $method = 'GET';

	public function action_endpoint() {
		return 'lists/1/1000.json';
	}

	public function send_request() {
		$response = parent::send_request();

		if ( ! empty( $response['Context']['MailingLists'] ) ) {
			return $response;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
		throw new Gateway_Exception( 'empty_lists', $response );
	}

	/**
	 * @return \Generator
	 */
	public function generate_lists(): \Generator {
		$response = $this->get_response_body();

		foreach ( $response['Context']['MailingLists'] as $list ) {
			yield array(
				'value' => $list['ID'],
				'label' => $list['Name'],
			);
		}
	}

	public function generate_fields(): \Generator {
		$response = $this->get_response_body();

		foreach ( $response['Context']['MailingLists'] as $list ) {
			yield $list['ID'] => array_values(
				iterator_to_array( $this->generate_fields_by_list( $list ) )
			);
		}
	}

	private function generate_fields_by_list( array $mailing_list ): \Generator {
		yield -2 => array(
			'value'    => 'Email',
			'label'    => __( 'Email', 'jet-form-builder-moosend-action' ),
			'required' => true,
		);
		yield -1 => array(
			'value' => 'Name',
			'label' => __( 'Name', 'jet-form-builder-moosend-action' ),
		);

		$custom_fields = $mailing_list['CustomFieldsDefinition'] ?? array();

		foreach ( $custom_fields as $custom_field ) {
			yield array(
				'value'    => $custom_field['ID'],
				'label'    => $custom_field['Name'],
				'required' => $custom_field['IsRequired'],
			);
		}
	}

}
