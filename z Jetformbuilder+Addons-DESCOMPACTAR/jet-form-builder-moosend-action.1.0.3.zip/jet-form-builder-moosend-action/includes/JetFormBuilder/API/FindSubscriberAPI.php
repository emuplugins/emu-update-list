<?php

namespace JFB\Moosend\JetFormBuilder\API;

class FindSubscriberAPI extends APIAction {

	protected $method = 'GET';
	private $email    = '';

	public function action_endpoint() {
		return 'subscribers/{list}/view.json';
	}

	public function action_body() {
		return array(
			'Email' => $this->get_email(),
		);
	}

	/**
	 * @param string $email
	 */
	public function set_email( string $email ): void {
		$this->email = $email;
	}


	/**
	 * @return string
	 */
	public function get_email(): string {
		return $this->email;
	}

}
