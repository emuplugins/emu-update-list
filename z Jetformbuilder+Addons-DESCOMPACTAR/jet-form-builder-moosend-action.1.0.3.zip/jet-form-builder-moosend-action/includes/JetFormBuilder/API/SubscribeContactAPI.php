<?php

namespace JFB\Moosend\JetFormBuilder\API;

class SubscribeContactAPI extends APIAction {

	private $fields_map = array();

	public function action_endpoint() {
		return 'subscribers/{list}/subscribe.json';
	}

	public function action_body() {
		return $this->get_fields_map();
	}

	/**
	 * @param array $fields_map
	 */
	public function set_fields_map( array $fields_map ): void {
		$this->fields_map = $fields_map;
	}

	/**
	 * @return array
	 */
	public function get_fields_map(): array {
		return $this->fields_map;
	}

}
