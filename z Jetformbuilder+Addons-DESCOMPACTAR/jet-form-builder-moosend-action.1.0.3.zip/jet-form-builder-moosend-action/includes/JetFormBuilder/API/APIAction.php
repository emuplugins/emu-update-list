<?php

namespace JFB\Moosend\JetFormBuilder\API;

use Jet_Form_Builder\Exceptions\Gateway_Exception;
use JFB_Modules\Gateways\Actions_Abstract\Action_Application_Raw_Body_It;
use JFB_Modules\Gateways\Base_Gateway_Action;

abstract class APIAction extends Base_Gateway_Action implements Action_Application_Raw_Body_It {

	protected $api_key = '';

	public function base_url(): string {
		return 'https://api.moosend.com/v3/';
	}

	public function action_query_args(): array {
		return array(
			'apiKey' => $this->get_api_key(),
		);
	}

	public function set_mailing_list( string $mailing_list ): void {
		$this->set_path(
			array(
				'list' => $mailing_list,
			)
		);
	}

	public function send_request() {
		$response = parent::send_request();

		if ( empty( $response['Error'] ) ) {
			return $response;
		}

		throw new Gateway_Exception( esc_html( $response['Error'] ) );
	}

	/**
	 * @return string
	 */
	public function get_api_key(): string {
		return $this->api_key;
	}

	/**
	 * @param string $api_key
	 */
	public function set_api_key( string $api_key ): void {
		$this->api_key = $api_key;
	}
}
