<?php

namespace JFB\Moosend\JetFormBuilder\API;

use JFB\Moosend\Plugin;

class ActionFactory {

	/**
	 * @var Plugin
	 */
	private $plugin;

	/**
	 * @var string
	 */
	private $api_key = '';

	/**
	 * @var string
	 */
	private $mailing_list = '';

	public function __construct(
		Plugin $plugin
	) {
		$this->plugin = $plugin;
	}

	public function create( string $class_name ): ?APIAction {
		/** @noinspection PhpUnhandledExceptionInspection */
		$instance = $this->plugin->get_injector()->make( $class_name );

		if ( ! ( $instance instanceof APIAction ) ) {
			return null;
		}

		$instance->set_api_key( $this->get_api_key() );
		$instance->set_mailing_list( $this->get_mailing_list() );

		return $instance;
	}

	/**
	 * @return string
	 */
	public function get_api_key(): string {
		return $this->api_key;
	}

	/**
	 * @param string $api_key
	 */
	public function set_api_key( string $api_key ): void {
		$this->api_key = $api_key;
	}

	/**
	 * @param string $mailing_list
	 */
	public function set_mailing_list( string $mailing_list ): void {
		$this->mailing_list = $mailing_list;
	}

	/**
	 * @return string
	 */
	public function get_mailing_list(): string {
		return $this->mailing_list;
	}

}
