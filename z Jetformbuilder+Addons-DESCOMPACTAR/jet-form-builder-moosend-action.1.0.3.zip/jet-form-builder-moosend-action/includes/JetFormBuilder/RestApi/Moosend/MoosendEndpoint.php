<?php

namespace JFB\Moosend\JetFormBuilder\RestApi\Moosend;

use Jet_Form_Builder\Exceptions\Gateway_Exception;
use JFB\Moosend\JetFormBuilder\API\ActionFactory;
use JFB\Moosend\JetFormBuilder\API\GetListsAPI;
use JFB_Components\Rest_Api\Interfaces\Endpoint_Interface;

class MoosendEndpoint implements Endpoint_Interface {

	/**
	 * @var ActionFactory
	 */
	private $factory;

	public function __construct(
		ActionFactory $factory
	) {
		$this->factory = $factory;
	}

	public function get_method(): string {
		return \WP_REST_Server::READABLE;
	}

	public function has_permission(): bool {
		return current_user_can( 'manage_options' );
	}

	public function get_args(): array {
		return array(
			'apiKey' => array(
				'type'     => 'string',
				'required' => true,
			),
		);
	}

	public function process( \WP_REST_Request $request ): \WP_REST_Response {
		$this->factory->set_api_key( $request['apiKey'] ?? '' );

		try {
			/** @var GetListsAPI $get_lists */
			$get_lists = $this->factory->create( GetListsAPI::class );
			$get_lists->send_request();
		} catch ( Gateway_Exception $exception ) {
			return new \WP_REST_Response(
				array(
					'code'    => 'not_found_lists',
					'message' => $exception->getMessage(),
				),
				404
			);
		}

		return new \WP_REST_Response(
			array(
				'lists'  => iterator_to_array( $get_lists->generate_lists() ),
				'fields' => iterator_to_array( $get_lists->generate_fields() ),
			)
		);
	}

}
