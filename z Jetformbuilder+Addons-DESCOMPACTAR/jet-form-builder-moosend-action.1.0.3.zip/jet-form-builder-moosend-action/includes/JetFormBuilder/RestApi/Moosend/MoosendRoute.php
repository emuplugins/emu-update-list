<?php

namespace JFB\Moosend\JetFormBuilder\RestApi\Moosend;

use JFB_Components\Rest_Api\Route;

class MoosendRoute extends Route {

	public function __construct(
		MoosendEndpoint $endpoint
	) {
		$this->set_namespace( 'jet-form-builder/v1' );
		$this->set_route( 'moosend' );
		$this->add_endpoint( $endpoint );
	}

}
