<?php

namespace JFB\Moosend\JetFormBuilder\RestApi;

use Jet_Form_Builder\Admin\Tabs_Handlers\Base_Handler;
use JFB\Moosend\JetFormBuilder\RestApi\Moosend\MoosendRoute;
use JFB\Moosend\Plugin;
use JFB\Moosend\Vendor\Auryn\InjectionException;

class RestApi {

	/**
	 * @var Plugin
	 */
	private $plugin;

	public function __construct(
		Plugin $plugin
	) {
		$this->plugin = $plugin;
	}

	public function init_hooks() {
		if ( ! class_exists( '\JFB_Modules\Actions_V2\Module' ) ) {
			return;
		}
		add_action(
			'rest_api_init',
			array( $this, 'rest_api_init' )
		);
	}

	/**
	 * @return void
	 * @throws InjectionException
	 */
	public function rest_api_init() {
		/** @var MoosendRoute $route */
		$route = $this->plugin->get_injector()->make( MoosendRoute::class );
		$route->register();

		register_setting(
			trim( Base_Handler::PREFIX, '_' ),
			Base_Handler::PREFIX . 'moosend',
			array(
				'type'         => 'string',
				'show_in_rest' => true,
				'default'      => '{}',
			)
		);
	}


}
