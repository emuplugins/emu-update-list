<?php

namespace JFB\Moosend\JetFormBuilder\Tabs;

use JFB\Moosend\Vendor\JFBCore\JetFormBuilder\RegisterFormTabs;

class ManagerTabs {

	use RegisterFormTabs;

	public function tabs(): array {
		return array(
			new ActionTab(),
		);
	}

	/**
	 * Supported only >= 3.4.0 JetFormBuilder
	 *
	 * @return bool
	 */
	public function can_init(): bool {
		return class_exists( '\JFB_Modules\Actions_V2\Module' );
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}
}
