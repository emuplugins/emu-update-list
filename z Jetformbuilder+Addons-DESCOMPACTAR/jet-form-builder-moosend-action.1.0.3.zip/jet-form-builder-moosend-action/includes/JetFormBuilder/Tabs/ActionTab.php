<?php


namespace JFB\Moosend\JetFormBuilder\Tabs;

use JFB\Moosend\ActionTabTrait;
use JFB\Moosend\Plugin;
use Jet_Form_Builder\Admin\Tabs_Handlers\Base_Handler;

class ActionTab extends Base_Handler {

	use ActionTabTrait;

	public function before_assets() {
		$script_asset = require_once JET_FB_MOOSEND_ACTION_PATH . 'assets/js/builder.admin.asset.php';

		wp_enqueue_script(
			Plugin::SLUG,
			JET_FB_MOOSEND_ACTION_URL . 'assets/js/builder.admin.js',
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}
}
