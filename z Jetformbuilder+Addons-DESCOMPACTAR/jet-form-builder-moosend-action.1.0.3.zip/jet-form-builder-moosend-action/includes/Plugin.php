<?php

namespace JFB\Moosend;

use JFB\Moosend\JetEngine\Tabs\ManagerTabs as JEManagerTabs;
use JFB\Moosend\JetFormBuilder\API\ActionFactory;
use JFB\Moosend\JetFormBuilder\RestApi\RestApi;
use JFB\Moosend\JetFormBuilder\Tabs\ManagerTabs as JFBManagerTabs;
use JFB\Moosend\JetEngine\Notifications\Manager as JEActionManager;
use JFB\Moosend\JetFormBuilder\Actions\Manager as JFBActionManager;
use JFB\Moosend\Vendor\Auryn\Injector;
use JFB\Moosend\Vendor\JFBCore\LicenceProxy;

class Plugin {

	const SLUG = 'jet-form-builder-moosend-action';

	/**
	 * @var Injector
	 */
	private $injector;

	/** @noinspection PhpUnhandledExceptionInspection */
	public function __construct( Injector $injector ) {
		$this->injector = $injector;

		$injector->share( ActionFactory::class );
		$injector->share( RestApi::class );
	}

	/**
	 * @return void
	 * @throws Vendor\Auryn\InjectionException
	 */
	public function setup() {
		JEManagerTabs::register();
		JFBManagerTabs::register();

		JFBActionManager::register();
		JEActionManager::register();

		Handler::instance();

		LicenceProxy::register();

		/** @var RestApi $rest_api */
		$rest_api = $this->get_injector()->make( RestApi::class );
		$rest_api->init_hooks();
	}


	/**
	 * @return Injector
	 */
	public function get_injector(): Injector {
		return $this->injector;
	}

}
