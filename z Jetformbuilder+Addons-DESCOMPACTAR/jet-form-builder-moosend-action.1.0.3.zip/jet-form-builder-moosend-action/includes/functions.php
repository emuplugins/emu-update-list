<?php

use JFB\Moosend\Vendor\Auryn\Injector;
use JFB\Moosend\Vendor\Auryn\ConfigException;
use JFB\Moosend\Plugin;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

/**
 * @throws ConfigException
 */
function jet_fb_moosend_setup() {
	/** @var Plugin $plugin */

	$injector = new Injector();
	$plugin   = new Plugin( $injector );
	$injector->share( $plugin );

	$plugin->setup();

	add_filter(
		'jet-fb/moosend/injector',
		function () use ( $injector ) {
			return $injector;
		}
	);

	do_action( 'jet-fb/moosend/setup', $injector );
}

function jet_fb_moosend_injector(): Injector {
	return apply_filters( 'jet-fb/moosend/injector', false );
}
