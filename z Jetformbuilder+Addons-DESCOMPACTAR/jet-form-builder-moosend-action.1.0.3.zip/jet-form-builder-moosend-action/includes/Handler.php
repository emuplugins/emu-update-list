<?php

namespace JFB\Moosend;

use JFB\Moosend\Vendor\JFBCore\BaseHandler;
use JFB\Moosend\Vendor\JFBCore\Common\Tools;
use JFB\Moosend\Vendor\JFBCore\Exceptions\ApiHandlerException;

class Handler extends BaseHandler {

	protected $api_base_url = 'https://api.moosend.com/v3/';

	public function ajax_action(): string {
		return 'jet_form_builder_get_moosend_data';
	}

	public function get_api_request_args() {
		return array(
			'body' => array(
				'apiKey' => $this->request_args['api_key'] ?? '',
			),
		);
	}

	/**
	 * @return array
	 * @throws ApiHandlerException
	 */
	public function get_all_data() {
		$response = $this->request( 'lists/1/1000.json' );

		if ( $response['Error'] ) {
			throw new ApiHandlerException( $response['Error'] );
		}
		if ( empty( $response['Context']['MailingLists'] ) ) {
			throw new ApiHandlerException( 'empty_lists', $response );
		}

		$lists = $response['Context']['MailingLists'];

		return array(
			'mailing_list' => Tools::prepare_list_for_js( $lists, 'ID', 'Name' ),
			'fields'       => $this->prepare_fields( $lists ),
		);
	}

	public function prepare_fields( $lists ) {
		$fields = array();

		foreach ( $lists as $list ) {
			$ID            = $list['ID'];
			$custom_fields = $list['CustomFieldsDefinition'];

			$fields[ $ID ] = array(
				'Email' => array(
					'label'    => __( 'Email', 'jet-form-builder-moosend-action' ),
					'required' => true,
				),
				'Name'  => array(
					'label' => __( 'Name', 'jet-form-builder-moosend-action' ),
				),
			);
			foreach ( $custom_fields as $custom_field ) {
				$fields[ $ID ][ $custom_field['ID'] ] = array(
					'label'    => $custom_field['Name'],
					'required' => $custom_field['IsRequired'],
				);
			}
		}

		return $fields;
	}

	public static $instance = null;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new static();
		}

		return self::$instance;
	}

}
