<?php

namespace JFB\Moosend\Vendor\JFBCore\Exceptions;

class ApiHandlerException extends BaseHandlerException
{
}
