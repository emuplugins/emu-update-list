<?php

namespace JFB\Moosend\Vendor\Auryn;

class InjectorException extends \Exception
{
}
