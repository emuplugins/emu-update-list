<?php

namespace JFB\Moosend\Vendor\Auryn;

class ConfigException extends InjectorException
{
}
