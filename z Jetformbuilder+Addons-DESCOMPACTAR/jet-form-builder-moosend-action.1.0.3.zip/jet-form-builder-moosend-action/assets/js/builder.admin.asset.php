<?php return array('dependencies' => array(), 'version' => 'f077baeffc2b46a295cf');
