<?php return array('dependencies' => array('wp-hooks'), 'version' => '07484c61cb0b4e85d43a');
