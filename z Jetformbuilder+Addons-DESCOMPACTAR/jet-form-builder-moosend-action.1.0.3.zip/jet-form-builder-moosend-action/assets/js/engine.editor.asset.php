<?php return array('dependencies' => array('wp-hooks'), 'version' => '23f69813714ba8132873');
