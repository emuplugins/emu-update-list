<?php

namespace JFB_Formless\Modules\Listeners;

final class Module {

	public function __construct(
		RestAPI $rest,
		WPAjax $ajax,
		URLQuery $query
	) {
	}

}
