<?php

namespace JFB_Formless\DB\Views;

use Jet_Form_Builder\Db_Queries\Views\View_Base_Count_Trait;

class RequestLogsCount extends RequestLogs {

	use View_Base_Count_Trait;
}
