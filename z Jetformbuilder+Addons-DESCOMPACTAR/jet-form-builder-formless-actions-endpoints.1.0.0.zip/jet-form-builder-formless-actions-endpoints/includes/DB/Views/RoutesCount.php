<?php

namespace JFB_Formless\DB\Views;

use Jet_Form_Builder\Db_Queries\Views\View_Base_Count_Trait;

class RoutesCount extends Routes {

	use View_Base_Count_Trait;
}
