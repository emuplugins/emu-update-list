<?php

namespace JFB_Formless\Services;

class ValidateException extends \Exception {

}