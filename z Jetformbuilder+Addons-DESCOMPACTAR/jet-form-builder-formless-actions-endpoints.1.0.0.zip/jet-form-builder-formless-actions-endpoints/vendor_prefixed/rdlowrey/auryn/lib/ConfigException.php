<?php

namespace JFB_Formless\Vendor\Auryn;

class ConfigException extends InjectorException
{
}
