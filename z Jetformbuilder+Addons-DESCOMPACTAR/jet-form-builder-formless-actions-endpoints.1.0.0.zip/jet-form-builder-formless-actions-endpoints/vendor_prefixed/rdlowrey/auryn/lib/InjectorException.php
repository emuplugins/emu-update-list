<?php

namespace JFB_Formless\Vendor\Auryn;

class InjectorException extends \Exception
{
}
