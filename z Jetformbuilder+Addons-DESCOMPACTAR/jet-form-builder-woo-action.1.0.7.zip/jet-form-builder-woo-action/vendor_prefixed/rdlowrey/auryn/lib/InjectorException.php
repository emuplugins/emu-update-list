<?php

namespace JFB\WooComm\Vendor\Auryn;

class InjectorException extends \Exception
{
}
