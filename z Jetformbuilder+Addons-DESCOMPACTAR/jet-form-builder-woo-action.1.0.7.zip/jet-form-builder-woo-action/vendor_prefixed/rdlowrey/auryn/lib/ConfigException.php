<?php

namespace JFB\WooComm\Vendor\Auryn;

class ConfigException extends InjectorException
{
}
