<?php

namespace JFB\WooComm\Vendor\JFBCore\Exceptions;

class ApiHandlerException extends BaseHandlerException
{
}
