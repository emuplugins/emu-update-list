<?php


namespace Jet_FB_Woo\JetEngine\Notifications;


use Jet_FB_Woo\ActionTrait;
use JFB\WooComm\Vendor\JFBCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use ActionTrait;

}