# jet-form-builder-limit-form-responses
Premium addon for JetFormBuilder &amp; JetEngine Forms

# ChangeLog

## 1.1.0
* ADD: Reset counter after period

## 1.0.3
* FIX: starting session only if it needed

## 1.0.2
* Tweak: Removed unnecessary hook

## 1.0.1
* Tweak: add license manager
