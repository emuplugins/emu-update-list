<?php


namespace Jet_FB_Limit_Form_Responses\JetEngine;

use Jet_FB_Limit_Form_Responses\PreventRenderTrait;
use JetLimitResponsesCore\JetEngine\PreventFormRender;

class PreventRender extends PreventFormRender {

	use PreventRenderTrait;

}