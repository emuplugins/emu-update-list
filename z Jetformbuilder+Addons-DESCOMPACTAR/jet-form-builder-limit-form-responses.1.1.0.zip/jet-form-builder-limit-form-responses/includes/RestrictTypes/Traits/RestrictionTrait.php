<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes\Traits;

use Jet_FB_Limit_Form_Responses\CycleCounter;
use Jet_FB_Limit_Form_Responses\LimitResponses;

trait RestrictionTrait {

	private $counter;

	public function set_counter( CycleCounter $counter ) {
		$this->counter = $counter;
	}

	public function get_counter(): CycleCounter {
		return $this->counter;
	}

	/**
	 * @return bool
	 */
	public function is_reached_limit(): bool {
		return $this->get_counter()->is_reached_limit();
	}

	public function set_form_id( int $form_id ) {
		LimitResponses::instance()->set_form_id( $form_id );
	}

	public function get_form_id(): int {
		return LimitResponses::instance()->get_form_id();
	}

	public function get_setting( string $name ) {
		return LimitResponses::instance()->get_setting( $name );
	}

	public function set_settings( array $settings ) {
		LimitResponses::instance()->set_settings( $settings );
	}

	public function get_settings(): array {
		return LimitResponses::instance()->get_settings();
	}

	public function set_setting( string $name, $value ) {
		LimitResponses::instance()->set_setting( $name, $value );
	}
}
