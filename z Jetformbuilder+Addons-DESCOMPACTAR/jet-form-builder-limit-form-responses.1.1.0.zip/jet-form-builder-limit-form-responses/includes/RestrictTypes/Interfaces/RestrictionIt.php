<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes\Interfaces;

use Jet_FB_Limit_Form_Responses\CycleCounter;
use Jet_FB_Limit_Form_Responses\Interfaces\FormIt;
use Jet_FB_Limit_Form_Responses\Interfaces\SettingsIt;

interface RestrictionIt extends SettingsIt, FormIt {

	public function get_id(): string;

	public function is_reached_limit(): bool;

	public function increment();

	public function set_counter( CycleCounter $counter );

	public function get_counter(): CycleCounter;

	public function before_run();

}
