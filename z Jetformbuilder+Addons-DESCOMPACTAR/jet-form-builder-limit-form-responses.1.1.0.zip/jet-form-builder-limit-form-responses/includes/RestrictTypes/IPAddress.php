<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;

use Jet_FB_Limit_Form_Responses\LimitResponses;
use Jet_FB_Limit_Form_Responses\RestrictTypes\Interfaces\RestrictionIt;
use Jet_FB_Limit_Form_Responses\RestrictTypes\Traits\RestrictionTrait;

class IPAddress implements RestrictionIt {

	use RestrictionTrait;

	private $client_ip;

	const RESTRICT_META_KEY = '_restrict_client_ip_addresses';

	public function get_id(): string {
		return 'id_address';
	}

	public function before_run() {
		$this->set_ip( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ) );

		$counters = self::resolve_counters();

		$this->get_counter()->set_count(
			(int) ( $counters[ self::RESTRICT_META_KEY ][ $this->client_ip ]['count'] ?? 0 )
		);
		$this->get_counter()->set_reset_at(
			(int) ( $counters[ self::RESTRICT_META_KEY ][ $this->client_ip ]['reset_at'] ?? - 1 )
		);
		$this->get_counter()->set_limit( (int) $this->get_setting( 'cycle_limit' ) );
		$this->get_counter()->set_cycle( (string) $this->get_setting( 'cycle' ) );
	}

	public function increment() {
		// increase reset_at timestamp
		$this->get_counter()->new_reset_at();

		$counters = self::resolve_counters();

		$counters[ self::RESTRICT_META_KEY ][ $this->client_ip ] = array(
			'count'    => 1 + $this->get_counter()->get_count(),
			'reset_at' => $this->get_counter()->get_reset_at(),
		);

		LimitResponses::update_counters( $counters );
	}

	protected function resolve_counters(): array {
		$meta_counters = LimitResponses::resolve_counters();

		$meta_counters[ self::RESTRICT_META_KEY ] = (
			$meta_counters[ self::RESTRICT_META_KEY ] ?? array()
		);

		$meta = &$meta_counters[ self::RESTRICT_META_KEY ];

		if ( ! isset( $meta[ $this->client_ip ] ) ) {
			$meta[ $this->client_ip ] = 0;
		}

		if ( ! is_array( $meta[ $this->client_ip ] ) ) {
			$meta[ $this->client_ip ] = array(
				'count'    => $meta[ $this->client_ip ],
				'reset_at' => - 1,
			);
		}

		return $meta_counters;
	}

	private function set_ip( $ip ) {
		$this->client_ip = $ip;
	}
}
