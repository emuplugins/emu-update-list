<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;

use Jet_FB_Limit_Form_Responses\RestrictTypes\Interfaces\RestrictionIt;
use Jet_FB_Limit_Form_Responses\RestrictTypes\Traits\RestrictionTrait;
use Jet_FB_Limit_Form_Responses\Exceptions\LimitException;
use Jet_FB_Limit_Form_Responses\LimitResponses;

class LoggedUser implements RestrictionIt {

	use RestrictionTrait;

	private $user_meta;
	private $user_id;

	public function get_id(): string {
		return 'user';
	}

	/**
	 * @throws LimitException
	 */
	public function before_run() {
		$this->user_meta = $this->get_user_meta();
		$this->user_id   = $this->get_user_id_or_throw();
		$form_id         = $this->get_form_id();

		if ( ! isset( $this->user_meta[ $form_id ] ) ) {
			$this->user_meta[ $form_id ] = 0;
		}

		if ( ! is_array( $this->user_meta[ $form_id ] ) ) {
			$this->user_meta[ $form_id ] = array(
				'count'    => $this->user_meta[ $form_id ],
				'reset_at' => - 1,
			);
		}

		$meta = $this->user_meta[ $form_id ];

		$this->get_counter()->set_count( (int) $meta['count'] );
		$this->get_counter()->set_reset_at( (int) $meta['reset_at'] );
		$this->get_counter()->set_limit( (int) $this->get_setting( 'cycle_limit' ) );
		$this->get_counter()->set_cycle( (string) $this->get_setting( 'cycle' ) );
	}

	public function increment() {
		// increase reset_at timestamp
		$this->get_counter()->new_reset_at();

		$this->user_meta[ $this->get_form_id() ] = array(
			'count'    => 1 + $this->get_counter()->get_count(),
			'reset_at' => $this->get_counter()->get_reset_at(),
		);

		$this->update_user_meta();
	}

	/**
	 * @return bool|int
	 */
	private function update_user_meta() {
		return update_user_meta(
			$this->user_id,
			LimitResponses::PLUGIN_META_KEY,
			json_encode( $this->user_meta ) // phpcs:ignore WordPress.WP.AlternativeFunctions
		);
	}

	/**
	 * @return array
	 * @throws LimitException
	 */
	private function get_user_meta(): array {
		$user_id       = $this->get_user_id_or_throw();
		$all_user_meta = get_user_meta( $user_id, LimitResponses::PLUGIN_META_KEY, true );

		return $all_user_meta
			? json_decode( $all_user_meta, true )
			: array();
	}

	/**
	 * @return int
	 * @throws LimitException
	 */
	private function get_user_id_or_throw(): int {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
			throw new LimitException( LimitResponses::GUEST_MESSAGE );
		}

		return $user_id;
	}
}
