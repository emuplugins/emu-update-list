<?php


namespace Jet_FB_Limit_Form_Responses\RestrictTypes;

use Jet_FB_Limit_Form_Responses\LimitResponses;
use Jet_FB_Limit_Form_Responses\RestrictTypes\Interfaces\RestrictionIt;
use Jet_FB_Limit_Form_Responses\RestrictTypes\Traits\RestrictionTrait;

class General implements RestrictionIt {

	const SUBMISSIONS_KEY = '_form_submissions';

	use RestrictionTrait;

	public function get_id(): string {
		return 'general';
	}

	public function before_run() {
	}

	public function is_reached_limit(): bool {
		$limit = $this->get_setting( 'limit' ) >= 1
			? ( (int) $this->get_setting( 'limit' ) )
			: 1;

		$counters = LimitResponses::resolve_counters();

		return $limit <= ( $counters[ self::SUBMISSIONS_KEY ]['count'] ?? 0 );
	}

	public function increment() {
		$counters = LimitResponses::resolve_counters();

		$counters[ self::SUBMISSIONS_KEY ] = $counters[ self::SUBMISSIONS_KEY ] ?? array( 'count' => 0 );
		++$counters[ self::SUBMISSIONS_KEY ]['count'];

		LimitResponses::update_counters( $counters );
	}

}
