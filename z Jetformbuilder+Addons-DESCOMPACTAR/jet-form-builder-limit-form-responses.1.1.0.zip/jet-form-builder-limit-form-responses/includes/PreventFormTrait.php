<?php


namespace Jet_FB_Limit_Form_Responses;

use Jet_FB_Limit_Form_Responses\Exceptions\LimitException;

trait PreventFormTrait {

	protected $is_reached = false;
	protected $message;
	protected $type;

	public function run_increment() {
		return true;
	}

	abstract public function get_message_type_on_general_limit();

	abstract public function get_message_type_on_restrict_limit();

	abstract public function send_response_or_process( $form_id, $handler );

	protected function send_response_on_reached_limit( $form_id, $handler = null ) {
		LimitResponses::instance()->set_form_id( absint( $form_id ) );
		LimitResponses::instance()->set_settings( LimitResponses::resolve_settings() );

		try {
			$this->check_general_restriction();
			$this->check_user_restriction();

		} catch ( LimitException $exception ) {
			$this->is_reached = true;
			$this->message    = LimitResponses::instance()->get_message_by_type( $this->type );
		}

		/**
		 * Run incrementing counter only if there weren't LimitExceptions
		 */
		if ( ! $this->is_reached && $this->run_increment() ) {
			LimitResponses::instance()->try_to_increment_general();
			LimitResponses::instance()->try_to_increment();
		}

		$response = $this->send_response_or_process( $form_id, $handler );

		LimitResponses::clear();
		$this->is_reached = false;
		$this->type       = null;
		$this->message    = null;

		return $response;
	}

	/**
	 * @throws LimitException
	 */
	protected function check_general_restriction() {
		try {
			LimitResponses::instance()->is_reached_general_limit();

		} catch ( LimitException $exception ) {
			$this->type = $this->get_message_type_on_general_limit();

			throw $exception;
		}
	}

	/**
	 * @throws LimitException
	 */
	protected function check_user_restriction() {
		$restriction = LimitResponses::instance()->get_restriction();

		if ( ! $restriction ) {
			return;
		}

		$restriction->set_counter( new CycleCounter() );

		try {
			$restriction->before_run();

			LimitResponses::instance()->is_reached_limit();

		} catch ( LimitException $exception ) {
			$this->type = $this->get_message_type_on_restrict_limit();

			throw $exception;
		}
	}


}
