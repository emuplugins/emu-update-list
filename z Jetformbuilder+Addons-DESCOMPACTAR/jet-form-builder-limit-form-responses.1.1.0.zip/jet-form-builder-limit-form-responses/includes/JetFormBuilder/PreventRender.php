<?php


namespace Jet_FB_Limit_Form_Responses\JetFormBuilder;

use Jet_FB_Limit_Form_Responses\PreventRenderTrait;
use JetLimitResponsesCore\JetFormBuilder\PreventFormRender;

class PreventRender extends PreventFormRender {

	use PreventRenderTrait;

}