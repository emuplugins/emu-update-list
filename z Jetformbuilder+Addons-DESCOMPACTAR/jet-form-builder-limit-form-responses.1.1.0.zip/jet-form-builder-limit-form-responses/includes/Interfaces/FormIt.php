<?php


namespace Jet_FB_Limit_Form_Responses\Interfaces;

interface FormIt {

	public function set_form_id( int $form_id );

	public function get_form_id(): int;

}
