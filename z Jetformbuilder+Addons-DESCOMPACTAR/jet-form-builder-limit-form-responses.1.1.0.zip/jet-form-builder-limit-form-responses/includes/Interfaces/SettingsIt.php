<?php


namespace Jet_FB_Limit_Form_Responses\Interfaces;

interface SettingsIt {

	public function set_settings( array $settings );

	public function get_settings(): array;

	public function set_setting( string $name, $value );

	public function get_setting( string $name );

}
