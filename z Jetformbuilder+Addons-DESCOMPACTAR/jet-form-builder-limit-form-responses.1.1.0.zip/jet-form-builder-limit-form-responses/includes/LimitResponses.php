<?php


namespace Jet_FB_Limit_Form_Responses;

use Jet_FB_Limit_Form_Responses\Exceptions\LimitException;
use Jet_FB_Limit_Form_Responses\Interfaces\FormIt;
use Jet_FB_Limit_Form_Responses\Traits\FormTrait;
use Jet_FB_Limit_Form_Responses\Interfaces\SettingsIt;
use Jet_FB_Limit_Form_Responses\RestrictTypes;
use Jet_FB_Limit_Form_Responses\Traits\SettingsTrait;
use JetLimitResponsesCore\Common\MetaQuery;

class LimitResponses implements SettingsIt, FormIt {

	const PLUGIN_META_KEY         = '_jf_limit_responses';
	const PLUGIN_META_COUNTER_KEY = '_jf_limit_responses_counters';

	const CLOSED_MESSAGE   = 'closed_message';
	const ERROR_MESSAGE    = 'error_message';
	const GUEST_MESSAGE    = 'guest_message';
	const RESTRICT_MESSAGE = 'restricted_message';

	use SettingsTrait;
	use FormTrait;

	private $restrict_types = array();
	protected $general_type;

	private static $instance;

	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	public static function clear() {
		self::$instance = null;
	}

	private function __construct() {
		$this->register_restrict_user_types();

		$this->general_type = new RestrictTypes\General();
	}

	private function user_restrict_types() {
		return apply_filters(
			'jet-fb/limit-form-responses/register/restrict-user-types',
			array(
				new RestrictTypes\IPAddress(),
				new RestrictTypes\LoggedUser(),
				new RestrictTypes\Cookie(),
				new RestrictTypes\Session(),
			)
		);
	}

	public static function resolve_settings(): array {
		return MetaQuery::get_json_meta(
			array(
				'id'  => self::instance()->get_form_id(),
				'key' => self::PLUGIN_META_KEY,
			)
		);
	}

	public static function resolve_counters(): array {
		return MetaQuery::get_json_meta(
			array(
				'id'  => self::instance()->get_form_id(),
				'key' => self::PLUGIN_META_COUNTER_KEY,
			)
		);
	}

	public static function update_counters( $settings ) {
		return MetaQuery::set_json_meta(
			array(
				'id'    => self::instance()->get_form_id(),
				'value' => $settings,
				'key'   => self::PLUGIN_META_COUNTER_KEY,
			)
		);
	}

	public function try_to_increment() {
		if ( ! $this->get_setting( 'restrict_users' ) ) {
			return;
		}

		$this->get_restriction()->increment();
	}

	/**
	 * @throws LimitException
	 */
	public function is_reached_limit() {
		if ( ! $this->get_setting( 'restrict_users' ) ) {
			return;
		}

		if ( $this->get_restriction()->is_reached_limit() ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
			throw new LimitException( 'failed' );
		}
	}

	public function try_to_increment_general() {
		if ( ! $this->get_setting( 'enable' ) ) {
			return;
		}

		$this->general_type->increment();
	}

	/**
	 * @throws LimitException
	 */
	public function is_reached_general_limit() {
		if ( ! $this->get_setting( 'enable' ) ) {
			return;
		}

		if ( $this->general_type->is_reached_limit() ) {
			throw new LimitException( 'general' );
		}
	}

	private function register_restrict_user_types() {
		$types = $this->user_restrict_types();

		foreach ( $types as $type ) {
			if (
				$type instanceof RestrictTypes\Interfaces\RestrictionIt
			) {
				$this->restrict_types[ $type->get_id() ] = $type;
			}
		}
	}


	/**
	 * @return RestrictTypes\Interfaces\RestrictionIt|false
	 */
	public function get_restriction() {
		$restrict_by = $this->get_setting( 'restrict_by' );
		$restrict_by = $restrict_by ?: 'id_address';

		return $this->restrict_types[ $restrict_by ] ?? false;
	}

	public function get_message_by_type( $type ) {
		$defaults = array(
			self::GUEST_MESSAGE    => 'Please log in to submit the form',
			self::ERROR_MESSAGE    => 'This form can no longer accept your request, sorry',
			self::RESTRICT_MESSAGE => 'You have already submitted a request from this form',
			self::CLOSED_MESSAGE   => 'This form is no longer available',
		);

		return $this->get_setting( $type ) ?: $defaults[ $type ];
	}

}
