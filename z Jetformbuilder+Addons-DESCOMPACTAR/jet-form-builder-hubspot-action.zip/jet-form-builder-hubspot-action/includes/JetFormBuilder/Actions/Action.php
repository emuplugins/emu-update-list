<?php

namespace Jet_FB_HubSpot\JetFormBuilder\Actions;

use Jet_FB_HubSpot\BaseAction;
use JetHubSpotCore\JetFormBuilder\SmartBaseAction;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Define Base_Type class
 */
class Action extends SmartBaseAction {

	use BaseAction;

	public function getGlobalSettingsKeys() {
		return array(
			'api_key' => ''
		);
	}
}


