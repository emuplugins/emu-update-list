<?php

namespace Jet_FB_HubSpot;

class HubSpotOAuthException extends \Exception {

}