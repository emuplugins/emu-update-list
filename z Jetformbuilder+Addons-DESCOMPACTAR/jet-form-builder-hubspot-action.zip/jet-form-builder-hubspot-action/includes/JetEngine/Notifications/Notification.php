<?php


namespace Jet_FB_HubSpot\JetEngine\Notifications;


use Jet_FB_HubSpot\BaseAction;
use Jet_FB_HubSpot\Plugin;
use JetHubSpotCore\JetEngine\SmartBaseNotification;

class Notification extends SmartBaseNotification {

	use BaseAction;

}