<?php


namespace Jet_FB_HubSpot;

if ( ! defined( 'WPINC' ) ) {
	die();
}

abstract class OAuthHandler {

	const BASE_ARG   = 'jet_hubspot_oauth';
	const ACTION_ARG = self::BASE_ARG . '[action]';
	const RESULT_ARG = self::BASE_ARG . '[result]';

	protected $admin_url            = '';
	protected $access_token_suffix  = '--access_token';
	protected $refresh_token_suffix = '--refresh_token';

	/**
	 * @return string
	 */
	abstract public function get_action();

	/**
	 * @return string
	 */
	abstract public function get_option_name();

	/**
	 * @return array
	 */
	abstract public function get_options();

	public function handle_request() {
		if ( isset( $_GET[ self::BASE_ARG ] ) ) {
			list( 'action' => $action, 'result' => $result ) = $_GET[ self::BASE_ARG ];

			if ( $this->get_action() !== $action ) {
				return;
			}

			$classes = array( 'notice' );

			switch ( $result ) {
				case 'success':
					$classes[] = 'notice-success';

					$message = __(
						'Your application is successfully authorized via OAuth 2.0',
						'jet-form-builder-hubspot-action'
					);
					break;
				case 'error':
					$classes[] = 'notice-error';

					$message = __(
						'Something went wrong, please try again.',
						'jet-form-builder-hubspot-action'
					);
					break;
				default:
					$classes[] = 'notice-error';

					$message = sanitize_text_field( $result );
			}

			$content    = sprintf( '<b>JetFormBuilder HubSpot Action:</b> %s', $message );
			$class_name = implode( ' ', $classes );

			add_action( 'admin_notices', function () use ( $class_name, $content ) {
				printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class_name ), wp_kses_post( $content ) );
			} );

		} else {
			add_action( "admin_action_{$this->get_action()}", array( $this, 'on_catch_action' ) );
		}
	}

	public function get_access_token( $type = 'token' ) {
		$json    = get_transient( $this->get_option_name() . $this->access_token_suffix );
		$decoded = $json ? json_decode( $json, true ) : array();

		if ( ! $type ) {
			return $decoded;
		}

		return isset( $decoded[ $type ] ) ? $decoded[ $type ] : false;
	}

	public function get_refresh_token() {
		$name          = $this->get_option_name() . $this->refresh_token_suffix;
		$refresh_token = get_option( $name );

		if ( $refresh_token ) {
			return $refresh_token;
		}

		// backward compatibility
		$refresh_token = get_transient( $name );

		delete_transient( $name );
		$this->set_refresh_token( $refresh_token );

		return $refresh_token;
	}

	public function set_refresh_token( string $token ) {
		update_option(
			$this->get_option_name() . $this->refresh_token_suffix,
			$token,
			false
		);
	}

	/**
	 * @param string $return_type
	 *
	 * @return array|mixed
	 * @throws HubSpotOAuthException
	 */
	public function refresh_and_get_access_token( $return_type = 'token' ) {
		$options = $this->get_options();

		if ( ! isset( $options['use_oauth'] ) || ! $options['use_oauth'] ) {
			throw new HubSpotOAuthException( 'Arg `use_oauth` is not enabled' );
		}

		$access_token = $this->get_access_token( $return_type );

		if ( $access_token ) {
			return $access_token;
		}

		$refresh_token = $this->get_refresh_token();

		if ( ! $refresh_token ) {
			throw new HubSpotOAuthException( 'Arg `refresh_token` is undefined' );
		}

		$options['refresh_token'] = $refresh_token;

		$request = $this->get_request_args( $options, 'refresh_token' );
		$tokens  = $this->get_tokens( $request );

		$this->save_tokens( $tokens );

		return $tokens['access_token'];

	}

	/**
	 * @param $request_args
	 *
	 * @return array
	 * @throws HubSpotOAuthException
	 */
	public function get_tokens( $request_args ) {
		$response = wp_remote_post( 'https://api.hubapi.com/oauth/v1/token', $request_args );

		if ( ! $response
		     || is_wp_error( $response )
		     || $response['response']['code'] !== 200
		) {
			$body = json_decode( $response['body'], true );

			throw new HubSpotOAuthException( $body['message'] ?? 'Failed request' );
		}

		return json_decode( $response['body'], true );
	}

	public function get_request_args( $source_options, $type = 'authorization_code' ) {
		$body = $this->array_filter_multiple(
			function ( $value, $key ) use ( $type ) {
				return in_array( $key, array(
					'client_id',
					'client_secret',

					/* for: $type -> authorization_code */
					'code',

					/* for: $type -> refresh_token */
					'refresh_token',
				) );
			},
			$_GET,
			$source_options
		);

		$body['grant_type']   = $type;
		$body['redirect_uri'] = $this->get_redirect_base_uri();

		return array(
			'headers' => array(
				'Content-Type' => 'application/x-www-form-urlencoded'
			),
			'body'    => $body
		);
	}

	public function on_catch_action() {
		try {
			$this->base_handler( $this->get_options() );

			wp_safe_redirect( add_query_arg(
				array(
					self::RESULT_ARG => 'success',
					self::ACTION_ARG => $this->get_action()
				),
				$this->admin_url()
			) );

		} catch ( HubSpotOAuthException $exception ) {
			wp_safe_redirect( add_query_arg( array(
				self::RESULT_ARG => $exception->getMessage(),
				self::ACTION_ARG => $this->get_action()
			), $this->admin_url() ) );
		}
	}

	/**
	 * @param $options
	 *
	 * @throws HubSpotOAuthException
	 */
	private function base_handler( $options ) {
		$request  = $this->get_request_args( $options );
		$response = $this->get_tokens( $request );

		$this->save_tokens( $response );
	}

	/**
	 * @param $tokens
	 *
	 * @return array
	 * @throws HubSpotOAuthException
	 */
	public function save_tokens( $tokens ) {
		$is_saved_access = false;
		$expires_in      = isset( $tokens['expires_in'] ) ? $tokens['expires_in'] * 0.8 : 0;

		if ( ! empty( $tokens['access_token'] ) ) {
			$json = wp_json_encode( array(
				'token' => $tokens['access_token'],
				'date'  => current_time( 'timestamp' )
			) );

			$is_saved_access = set_transient(
				$this->get_option_name() . $this->access_token_suffix,
				$json,
				$expires_in
			);
		}

		if ( ! empty( $tokens['refresh_token'] ) ) {
			$this->set_refresh_token( $tokens['refresh_token'] );
		}

		if ( ! $is_saved_access ) {
			throw new HubSpotOAuthException( 'Unsuccessful save access token.' );
		}

		return array( true, $expires_in );
	}


	/**
	 * @param $callback
	 * ex: function( $value, $key ) { return true; }
	 *
	 * @param mixed ...$sources
	 *
	 * @return array
	 */
	private function array_filter_multiple( $callback, ...$sources ) {
		$result = [];

		foreach ( $sources as $source ) {
			foreach ( $source as $item_key => $item_value ) {
				$result_callback = call_user_func( $callback, $item_value, $item_key );

				if ( ! $result_callback ) {
					continue;
				}
				$result[ $item_key ] = $item_value;
			}
		}

		return $result;
	}

	public function admin_url( $path = '' ) {
		if ( ! $this->admin_url ) {
			$this->admin_url = admin_url();

			if ( ! preg_match( '/\/\/(localhost|127\.0\.0\.1)/', $this->admin_url ) ) {
				$this->admin_url = str_replace( 'http:', 'https:', $this->admin_url );
			}
		}

		return ( $this->admin_url . $path );
	}

	public function get_redirect_base_uri() {
		return add_query_arg( array(
			'action' => $this->get_action()
		), $this->admin_url( 'admin.php' ) );
	}
}