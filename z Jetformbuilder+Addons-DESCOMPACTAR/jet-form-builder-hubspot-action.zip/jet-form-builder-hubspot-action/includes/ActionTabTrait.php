<?php


namespace Jet_FB_HubSpot;


trait ActionTabTrait {

	public function slug() {
		return 'hubspot';
	}

	/**
	 * @return OAuthHandler
	 */
	abstract public function get_oauth_handler();

	public function get_redirect_base_uri() {
		return $this->get_oauth_handler()->get_redirect_base_uri();
	}

	public function get_transient_access_token() {
		$token = $this->get_oauth_handler()->get_access_token();

		return strlen( $token );
	}

	public function on_get_request() {
		$result = $this->update_options(
			$this->sanitize_options( $_POST, array(
				'use_oauth'     => 'boolval',
				'api_key'       => 'sanitize_text_field',
				'client_id'     => 'sanitize_text_field',
				'client_secret' => 'sanitize_text_field',
				'redirect_uri'  => '',
			) )
		);

		$result ? wp_send_json_success( array(
			'message' => __( 'Saved successfully!', 'jet-form-builder' )
		) ) : wp_send_json_error( array(
			'message' => __( 'Unsuccessful save.', 'jet-form-builder' )
		) );
	}

	public function on_load() {
		return array_merge( $this->get_options( array(
			'use_oauth'     => false,
			'api_key'       => '',
			'client_id'     => '',
			'client_secret' => '',
			'redirect_uri'  => ''
		) ), array(
			'redirect_base' => $this->get_redirect_base_uri(),
			'is_auth'       => $this->get_transient_access_token()
		) );
	}

	public function sanitize_options( $source, $rules ) {
		$sanitized = array();

		foreach ( $rules as $setting => $callback ) {
			if ( ! isset( $source[ $setting ] ) ) {
				continue;
			}

			$sanitized[ $setting ] = is_callable( $callback )
				? call_user_func( $callback, $source[ $setting ] )
				: $source[ $setting ];
		}

		return $sanitized;
	}

}