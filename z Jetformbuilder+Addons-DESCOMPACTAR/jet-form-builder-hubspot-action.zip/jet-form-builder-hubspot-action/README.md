# JetFormBuilder Hubspot Action
Addon for JetFormBuilder & JetEngine Forms

# ChangeLog

## 1.1.6
* FIX: API key field has become required
* FIX: HubSpot Action has been moved to the `Communication & Notifications` category

## 1.1.5
* FIX: `refresh_token` is undefined

## 1.1.4
* FIX: Compatibility with php < 8.0.2

## 1.1.3
* ADD: php filter `jet-form-builder/hubspot/properties` & `jet-form-builder/hubspot/editor-data`
* FIX: Error if mail already in hubspot

## 1.1.2
* Tweak: Removed unnecessary hook

## 1.1.1
* Tweak: add license manager

## 1.1.0
* ADD: OAuth 2.0 authorization

## 1.0.0
* Initial release
