<?php

use JFB\MailPoet\Vendor\Auryn\InjectionException;
use JFB\MailPoet\Vendor\Auryn\Injector;
use JFB\MailPoet\Vendor\Auryn\ConfigException;
use JFB\MailPoet\Plugin;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

/**
 * @throws ConfigException|InjectionException
 */
function jet_fb_mailpoet_setup() {
	/** @var Plugin $plugin */

	if ( ! class_exists( \MailPoet\API\API::class ) ) {
		return;
	}

	$injector = new Injector();
	$plugin   = new Plugin( $injector );
	$injector->share( $plugin );

	$plugin->setup();

	add_filter(
		'jet-fb/mailpoet/injector',
		function () use ( $injector ) {
			return $injector;
		}
	);

	do_action( 'jet-fb/mailpoet/setup', $injector );
}

function jet_fb_mailpoet_injector(): Injector {
	return apply_filters( 'jet-fb/mailpoet/injector', false );
}
