<?php

namespace JFB\MailPoet;

use JFB\MailPoet\JetFormBuilder\Actions\Manager as JFBManager;
use JFB\MailPoet\JetEngine\Notifications\Manager as JEManager;
use JFB\MailPoet\JetFormBuilder\RestAPI\RestAPI;
use JFB\MailPoet\Vendor\Auryn\Injector;
use JFB\MailPoet\Vendor\JFBCore\LicenceProxy;


class Plugin {

	const SLUG = 'jet-form-builder-mailpoet-action';

	/**
	 * @var Injector
	 */
	private $injector;

	/**
	 * @param Injector $injector
	 *
	 * @throws Vendor\Auryn\ConfigException
	 */
	public function __construct( Injector $injector ) {
		$this->injector = $injector;

		$this->injector->share( RestAPI::class );
	}

	/**
	 * @return void
	 * @throws Vendor\Auryn\InjectionException
	 */
	public function setup() {
		JFBManager::register();
		JEManager::register();

		Handler::instance();

		LicenceProxy::register();

		/** @var RestAPI $rest_api */
		$rest_api = $this->injector->make( RestAPI::class );
		$rest_api->init_hooks();
	}

	/**
	 * @return Injector
	 */
	public function get_injector(): Injector {
		return $this->injector;
	}


}
