<?php


namespace JFB\MailPoet;

use Jet_Form_Builder\Exceptions\Action_Exception;
use JFB\MailPoet\Vendor\JFBCore\Exceptions\ApiHandlerException;
use JFB\MailPoet\Vendor\JFBCore\Exceptions\BaseHandlerException;
use JFB\MailPoet\Vendor\JFBCore\JetFormBuilder\ActionCompatibility;
use JFB\MailPoet\Vendor\JFBCore\SmartNotificationActionTrait;
use MailPoet\API\MP\v1\APIException;

/**
 * @method array getSettings()
 * @method mixed getRequest( $key = '', $ifNotExist = false )
 * @method array getSettingsWithGlobal()
 * @method string getGlobalOptionName()
 * @method string parseDynamicException( $type, $message )
 *
 * Trait BaseAction
 * @package JFB\MailPoet
 */
trait BaseAction {

	use ActionCompatibility;

	public function get_name() {
		return __( 'MailPoet', 'jet-form-builder-mailpoet-action' );
	}

	public function get_id() {
		return 'mailpoet';
	}

	/**
	 * @param $api_key
	 *
	 * @return mixed
	 */
	public function handler(): Handler {
		return Handler::instance();
	}

	/**
	 * Run a hook notification
	 *
	 * @return void
	 * @throws BaseHandlerException
	 */
	public function run_action() {
		$settings   = $this->getSettings();
		$subscriber = $this->prepare_subscriber();
		$list_ids   = $this->prepare_list_ids();

		$email = $subscriber['email'] ?? '';

		if ( empty( $email ) ) {
			throw new BaseHandlerException( 'empty_field', 'email' );
		}

		try {
			$exist_subscriber = $this->handler()->api()->getSubscriber( $email );

			$this->subscribe_to_lists( $exist_subscriber['id'], $list_ids, $settings );
		} catch ( APIException $exception ) {
			$this->create_subscriber( $subscriber, $list_ids, $settings );
		}
	}

	/**
	 * @param string $subscriber_id
	 * @param array $list_ids
	 * @param array $settings
	 *
	 * @throws BaseHandlerException
	 */
	protected function subscribe_to_lists( string $subscriber_id, array $list_ids, array $settings ) {
		try {
			$this->handler()->api()->subscribeToLists( $subscriber_id, $list_ids, $settings );
		} catch ( APIException $e ) {
			throw new BaseHandlerException(
				$this->parseDynamicException( 'error', $e->getMessage() )
			);
		}
	}

	/**
	 * @param array $subscriber
	 * @param array $list_ids
	 * @param array $settings
	 *
	 * @throws BaseHandlerException
	 */
	protected function create_subscriber( array $subscriber, array $list_ids, array $settings ) {
		try {
			$this->handler()->api()->addSubscriber( $subscriber, $list_ids, $settings );
		} catch ( APIException $e ) {
			throw new BaseHandlerException(
				$this->parseDynamicException( 'error', $e->getMessage() )
			);
		}
	}

	/**
	 * @return array
	 * @throws BaseHandlerException
	 */
	public function prepare_subscriber() {
		$settings = $this->getSettings();
		$request  = $this->getRequest();
		$response = array();

		if ( ! isset( $settings['fields_map'] ) || ! $settings['fields_map'] ) {
			throw new BaseHandlerException( 'internal_error', $settings );
		}

		foreach ( $settings['fields_map'] as $param => $field ) {
			if ( empty( $field ) || empty( $request[ $field ] ) ) {
				continue;
			}
			$response[ $param ] = $request[ $field ];
		}

		return $response;
	}

	public function prepare_list_ids() {
		$settings = $this->getSettings();

		if ( empty( $settings['list_ids'] ) ) {
			return array();
		}

		if ( wp_is_numeric_array( $settings['list_ids'] ) ) {
			return $settings['list_ids'];
		}

		// legacy support
		$ids = array_filter(
			$settings['list_ids'],
			function ( $val, $id ) {
				return ( is_int( $id ) && $val );
			},
			ARRAY_FILTER_USE_BOTH
		);

		return array_keys( $ids );
	}


}
