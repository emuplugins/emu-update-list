<?php


namespace JFB\MailPoet\JetEngine\Notifications;

use JFB\MailPoet\BaseAction;
use JFB\MailPoet\Vendor\JFBCore\JetEngine\SmartBaseNotification;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

class Notification extends SmartBaseNotification {

	use BaseAction;
}
