<?php


namespace JFB\MailPoet\JetEngine\Notifications;


use JFB\MailPoet\Plugin;
use JFB\MailPoet\Vendor\JFBCore\JetEngine\NotificationsManager;

class Manager extends NotificationsManager {

	public function register_notification() {
		return array(
			new Notification()
		);
	}

	/**
	 * Register notification assets
	 * @return void
	 */
	public function register_assets() {
		$script_asset = require_once JET_FB_MAILPOET_ACTION_PATH . 'assets/js/engine.editor.asset.php';

		wp_enqueue_script(
			Plugin::SLUG,
			JET_FB_MAILPOET_ACTION_URL . 'assets/js/engine.editor.js',
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice( 'warning', __(
			'<b>Warning</b>: <b>JetFormBuilder MailPoet Action</b> needs <b>JetEngine</b> update.',
			'jet-form-builder-mailpoet-action'
		) );
	}

	public function on_base_need_install() {
	}

}