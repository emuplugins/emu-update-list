<?php


namespace JFB\MailPoet\JetFormBuilder\Actions;

use JFB\MailPoet\Plugin;
use JFB\MailPoet\Vendor\JFBCore\JetFormBuilder\ActionsManager;

class Manager extends ActionsManager {

	public function register_controller( \Jet_Form_Builder\Actions\Manager $manager ) {
		$manager->register_action_type( new Action() );
	}

	/**
	 * @return void
	 */
	public function before_init_editor_assets() {
		$script_asset = require_once JET_FB_MAILPOET_ACTION_PATH . 'assets/js/builder.editor.asset.php';

		wp_enqueue_script(
			Plugin::SLUG,
			JET_FB_MAILPOET_ACTION_URL . 'assets/js/builder.editor.js',
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}

	public function on_base_need_update() {
		$this->add_admin_notice(
			'warning',
			__(
				'<b>Warning</b>: <b>JetFormBuilder MailPoet Action</b> needs <b>JetFormBuilder</b> update.',
				'jet-form-builder-mailpoet-action'
			)
		);
	}

	public function on_base_need_install() {
	}
}
