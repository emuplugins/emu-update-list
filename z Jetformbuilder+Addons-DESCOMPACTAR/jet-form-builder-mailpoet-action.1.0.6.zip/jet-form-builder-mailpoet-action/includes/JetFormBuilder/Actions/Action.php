<?php


namespace JFB\MailPoet\JetFormBuilder\Actions;

use JFB\MailPoet\BaseAction;
use JFB\MailPoet\Vendor\JFBCore\JetFormBuilder\SmartBaseAction;

class Action extends SmartBaseAction {

	use BaseAction;
}
