<?php

namespace JFB\MailPoet\JetFormBuilder\RestAPI\MailPoet;

use JFB\MailPoet\Handler;
use JFB_Components\Rest_Api\Interfaces\Endpoint_Interface;

class MailPoetEndpoint implements Endpoint_Interface {

	public function get_method(): string {
		return \WP_REST_Server::READABLE;
	}

	public function has_permission(): bool {
		return current_user_can( 'manage_options' );
	}


	public function get_args(): array {
		return array();
	}

	public function process( \WP_REST_Request $request ): \WP_REST_Response {
		$lists  = Handler::instance()->api()->getLists();
		$fields = Handler::instance()->api()->getSubscriberFields();

		return new \WP_REST_Response(
			array(
				'lists'  => Handler::instance()->prepare_lists( $lists ),
				'fields' => iterator_to_array( $this->prepare_fields( $fields ) ),
			)
		);
	}

	private function prepare_fields( array $fields ): \Generator {
		foreach ( $fields as $field ) {
			yield array(
				'value'    => $field['id'],
				'label'    => $field['name'],
				'required' => (bool) $field['params']['required'],
			);
		}
	}

}
