<?php

namespace JFB\MailPoet\JetFormBuilder\RestAPI\MailPoet;

use JFB_Components\Rest_Api\Route;

class MailPoetRoute extends Route {

	public function __construct(
		MailPoetEndpoint $endpoint
	) {
		$this->set_namespace( 'jet-form-builder/v1' );
		$this->set_route( 'mailpoet' );
		$this->add_endpoint( $endpoint );
	}

}
