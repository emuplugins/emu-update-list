<?php

namespace JFB\MailPoet\JetFormBuilder\RestAPI;

use JFB\MailPoet\JetFormBuilder\RestAPI\MailPoet\MailPoetRoute;
use JFB\MailPoet\Plugin;
use JFB\MailPoet\Vendor\Auryn\InjectionException;

class RestAPI {

	/**
	 * @var Plugin
	 */
	private $plugin;

	public function __construct(
		Plugin $plugin
	) {
		$this->plugin = $plugin;
	}

	public function init_hooks() {
		if ( ! class_exists( '\JFB_Modules\Actions_V2\Module' ) ) {
			return;
		}
		add_action(
			'rest_api_init',
			array( $this, 'rest_api_init' )
		);
	}

	/**
	 * @return void
	 * @throws InjectionException
	 */
	public function rest_api_init() {
		/** @var MailPoetRoute $route */
		$route = $this->plugin->get_injector()->make( MailPoetRoute::class );
		$route->register();
	}


}
