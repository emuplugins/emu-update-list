# JetFormBuilder MailPoet Action
Addon for JetFormBuilder & JetEngine

# ChangeLog

## 1.0.6
* UPD: make mailpoet action compatible with >= 3.4.0 JetFormBuilder

## 1.0.5
* Tweak: Update addon lib to 1.1.12

## 1.0.4
* FIX: User exists error

## 1.0.3
* FIX: JetFormBuilder action UI

## 1.0.2
* Tweak: Removed unnecessary hook

## 1.0.1
* Tweak: add license manager