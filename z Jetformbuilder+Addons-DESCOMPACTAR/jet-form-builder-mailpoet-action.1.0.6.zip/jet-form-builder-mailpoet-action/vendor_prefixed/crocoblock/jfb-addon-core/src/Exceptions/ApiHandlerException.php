<?php

namespace JFB\MailPoet\Vendor\JFBCore\Exceptions;

class ApiHandlerException extends BaseHandlerException
{
}
