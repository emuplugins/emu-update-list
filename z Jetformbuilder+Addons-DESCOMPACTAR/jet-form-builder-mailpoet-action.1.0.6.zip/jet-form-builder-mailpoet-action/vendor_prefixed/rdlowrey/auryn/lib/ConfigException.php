<?php

namespace JFB\MailPoet\Vendor\Auryn;

class ConfigException extends InjectorException
{
}
