<?php

namespace JFB\MailPoet\Vendor\Auryn;

class InjectorException extends \Exception
{
}
