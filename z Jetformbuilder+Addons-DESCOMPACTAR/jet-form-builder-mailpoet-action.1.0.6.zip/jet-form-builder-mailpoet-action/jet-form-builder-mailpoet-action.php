<?php
/**
 * Plugin Name: JetFormBuilder MailPoet Action
 * Plugin URI: https://jetformbuilder.com/addons/mailpoet/
 * Description: A form addon for more effective visitor data management and newsletter sending.
 * Version: 1.0.6
 * Author: Crocoblock
 * Author URI: https://crocoblock.com/
 * Text Domain: jet-form-builder-mailpoet-action
 * License: GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 * Requires PHP: 7.2
 * Requires at least: 6.0
 * Requires Plugins: mailpoet
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

define( 'JET_FB_MAILPOET_ACTION_VERSION', '1.0.6' );

define( 'JET_FB_MAILPOET_ACTION__FILE__', __FILE__ );
define( 'JET_FB_MAILPOET_ACTION_PLUGIN_BASE', plugin_basename( __FILE__ ) );
define( 'JET_FB_MAILPOET_ACTION_PATH', plugin_dir_path( __FILE__ ) );
define( 'JET_FB_MAILPOET_ACTION_URL', plugins_url( '/', __FILE__ ) );

require __DIR__ . '/includes/load.php';
