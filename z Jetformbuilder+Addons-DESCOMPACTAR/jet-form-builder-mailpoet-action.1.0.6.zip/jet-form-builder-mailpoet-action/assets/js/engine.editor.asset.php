<?php return array('dependencies' => array(), 'version' => '0f9dee5df9ab2af6a80c');
