# JetFormBuilder Hierarchical Select
Premium Addon for JetFormBuilder

# ChangeLog

## 1.0.5
* FIX: Fix empty required select

## 1.0.4
* ADD: Control for managing subsequent hierarchical selects based on parent-term child availability

## 1.0.3
* FIX: Use correct value for calculated field
* FIX: Correct generate field levels in fields list
* FIX: Compatibility with JetFormBuilder 3.1
* FIX: Not creating new terms
* FIX: Correct reporting on default validation

## 1.0.2
* UPD: JetFormBuilder 3.0 compatibility
* FIX: Query the taxonomies list
* FIX: Send form even if no terms added

## 1.0.1
* FIX: Fatal error when disabling JetFormBuilder

## 1.0.0
* Initial release