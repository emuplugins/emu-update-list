import HieraSelectData from './input';
import HieraSelectSignal from './signal';
import RequiredHierarchicalSelectRestriction from './RequiredHierarchicalSelectRestriction';

const { addFilter } = JetPlugins.hooks;

addFilter(
	'jet.fb.inputs',
	'jet-form-builder/hierarchical-select',
	function ( inputs ) {
		inputs = [ HieraSelectData, ...inputs ];
		return inputs;
	},
);

addFilter(
	'jet.fb.signals',
	'jet-form-builder/hierarchical-select',
	function ( signals ) {
		signals = [ HieraSelectSignal, ...signals ];
		return signals;
	},
);

addFilter(
	'jet.fb.restrictions.default',
	'jet-form-builder/hierarchical-select',
	function ( restrictions ) {
		restrictions.push( RequiredHierarchicalSelectRestriction );
		return restrictions;
	},
);