# JetFormBuilder Paypal Subscriptions
A tweak that allows you to create subscriptions and accept recurring payments via PayPal-integrated forms.

# ChangeLog

## 1.1.3
* FIX: Fix fatal error on subscription tabs when the 'Enable Gateways' option is disabled

## 1.1.2
* FIX: Ensure all PayPal subscription plans are displayed in the select dropdown
* FIX: Remove fatal error on some detail subscription pages
* FIX: webhook URL selection issue

## 1.1.1
* ADD: `RENEWAL.PAYMENT` Event to perform action in form when subscription is paid again
* FIX: Subscription not works correct if paypal-keys direct in form

## 1.1.0
* ADD: Subscription action events

## 1.0.1
* Tweak: Return queried resources in webhooks

## 1.0.0
* Initial release.