<?php


namespace Jet_FB_Paypal\RestEndpoints\Base;


interface WithMessages {

	public static function get_messages(): array;

}