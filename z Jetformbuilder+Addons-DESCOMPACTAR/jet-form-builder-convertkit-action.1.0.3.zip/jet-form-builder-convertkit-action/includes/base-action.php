<?php


namespace Jet_FB_ConvertKit;


use Jet_Form_Builder\Exceptions\Action_Exception;
use JetConvertKitCore\Exceptions\BaseHandlerException;
use JetConvertKitCore\JetFormBuilder\ActionCompatibility;

trait Base_Action {

	use ActionCompatibility;

	public function get_name() {
		return __( 'ConvertKit', 'jet-form-builder-convertkit-action' );
	}

	public function get_id() {
		return 'convertkit';
	}

	public function getGlobalOptionName() {
		return 'convert-kit-tab';
	}

	/**
	 * @param $api_key
	 *
	 * @return mixed
	 */
	public function api_handler( $api_key = '' ): Handler {
		return Handler::instance()->set_arg( 'api_key', $api_key );
	}

	/**
	 * Run a hook notification
	 *
	 * @return void
	 * @throws BaseHandlerException
	 */
	public function run_action() {
		$settings = $this->getSettingsWithGlobal();

		if ( empty( $settings['api_key'] ) || empty( $settings['tag_id'] ) ) {
			throw new BaseHandlerException( 'internal_error', $settings );
		}

		$handler = $this->api_handler( $settings['api_key'] );

		if ( is_wp_error( $handler ) ) {
			throw new BaseHandlerException( 'internal_error', $handler );
		}

		$end_point = sprintf( 'tags/%d/subscribe', (int) $settings['tag_id'] );

		$request_args = array(
			'method' => 'POST',
			'body'   => $this->prepare_fields_map( $settings ),
		);

		$response = $handler->request( $end_point, $request_args );

		if ( isset( $response['error'] ) ) {
			throw new BaseHandlerException( $this->parseDynamicException( 'error', $response['message'] ) );
		}
		if ( ! isset( $response['subscription'] ) ) {
			throw new BaseHandlerException( 'internal_error', $request_args, $response );
		}
	}

	/**
	 * @param $settings
	 *
	 * @return string
	 * @throws BaseHandlerException
	 */
	public function prepare_fields_map( $settings ) {
		$request = $this->getRequest();

		if ( empty( $settings['fields_map'] ) ) {
			throw new BaseHandlerException( 'internal_error', $settings );
		}

		$response = array(
			'api_key' => $settings['api_key']
		);

		foreach ( $settings['fields_map'] as $param => $field ) {

			if ( empty( $field ) || empty( $request[ $field ] ) ) {
				continue;
			}
			if ( in_array( $param, array( 'email', 'first_name' ), true ) ) {
				$response[ $param ] = $request[ $field ];
			} else {
				$response['fields'][ $param ] = $request[ $field ];
			}
		}

		return json_encode( $response );
	}

}