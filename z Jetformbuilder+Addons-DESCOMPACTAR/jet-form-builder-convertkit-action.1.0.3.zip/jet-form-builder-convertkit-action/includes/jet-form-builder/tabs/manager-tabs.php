<?php

namespace Jet_FB_ConvertKit\Jet_Form_Builder\Tabs;


use JetConvertKitCore\JetFormBuilder\RegisterFormTabs;

class Manager_Tabs {

	use RegisterFormTabs;

	public function tabs(): array {
		return array(
			new Convert_Kit_Tab()
		);
	}

	public function plugin_version_compare() {
		return '1.2.2';
	}

	public function on_base_need_update() {
	}

	public function on_base_need_install() {
	}
}