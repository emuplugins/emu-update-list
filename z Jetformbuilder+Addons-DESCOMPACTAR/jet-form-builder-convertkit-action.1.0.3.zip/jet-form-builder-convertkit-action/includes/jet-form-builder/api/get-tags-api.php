<?php

namespace Jet_FB_ConvertKit\Jet_Form_Builder\Api;

class Get_Tags_Api extends Base_Api_Action {

	protected $method = 'GET';

	public function action_endpoint() {
		return 'tags';
	}

	/**
	 * @return \Generator
	 */
	public function generate_list(): \Generator {
		$response = $this->get_response_body();

		foreach ( $response['tags'] as $tag ) {
			yield array(
				'value' => $tag['id'],
				'label' => $tag['name'],
			);
		}
	}

}
