<?php

namespace Jet_FB_ConvertKit\Jet_Form_Builder\Api;

class Get_Fields_Api extends Base_Api_Action {

	protected $method = 'GET';

	public function action_endpoint() {
		return 'custom_fields';
	}

	/**
	 * @return \Generator
	 */
	public function generate_list(): \Generator {
		$response = $this->get_response_body();

		yield - 2 => array(
			'value'    => 'email',
			'label'    => __( 'Email', 'jet-form-builder-convertkit-action' ),
			'required' => true,
		);

		yield - 1 => array(
			'value' => 'first_name',
			'label' => __( 'First Name', 'jet-form-builder-convertkit-action' ),
		);

		foreach ( $response['custom_fields'] as $field ) {
			yield array(
				'value' => $field['key'],
				'label' => $field['label'],
			);
		}
	}

}
