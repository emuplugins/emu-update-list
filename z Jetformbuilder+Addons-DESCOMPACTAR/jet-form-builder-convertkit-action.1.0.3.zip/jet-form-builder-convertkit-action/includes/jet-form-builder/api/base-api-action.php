<?php

namespace Jet_FB_ConvertKit\Jet_Form_Builder\Api;

use Jet_Form_Builder\Exceptions\Gateway_Exception;
use JFB_Modules\Gateways\Base_Gateway_Action;

class Base_Api_Action extends Base_Gateway_Action {

	private $api_key = '';

	public function base_url(): string {
		return 'https://api.convertkit.com/v3/';
	}

	public function send_request() {
		parent::send_request();

		$response = $this->get_response_body();

		if ( isset( $response['error'] ) ) {
			throw new Gateway_Exception(
				sprintf(
					'Error on request /%s',
					$this->action_endpoint() // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
				),
				$response // phpcs:ignore WordPress.Security.EscapeOutput.ExceptionNotEscaped
			);
		}
	}

	public function action_headers() {
		return array(
			'Content-Type' => 'application/json; charset=utf-8',
		);
	}

	public function action_query_args(): array {
		return array(
			'api_key' => $this->get_api_key(),
		);
	}

	/**
	 * @param string $api_key
	 */
	public function set_api_key( string $api_key ): void {
		$this->api_key = $api_key;
	}

	/**
	 * @return string
	 */
	public function get_api_key(): string {
		return $this->api_key;
	}

}
