<?php


namespace Jet_FB_ConvertKit\Jet_Form_Builder\Actions;

use Jet_FB_ConvertKit\Plugin;
use JetConvertKitCore\JetFormBuilder\ActionsManager;
use JFB_Modules\Actions_V2\Module;

class Manager extends ActionsManager {

	/**
	 * Supported only >= 3.4.0 JetFormBuilder
	 *
	 * @return bool
	 */
	public function can_init(): bool {
		return class_exists( '\JFB_Modules\Actions_V2\Module' );
	}

	public function register_controller( \Jet_Form_Builder\Actions\Manager $manager ) {
		$manager->register_action_type( new Action() );
	}

	/**
	 * @return void
	 */
	public function before_init_editor_assets() {
		$script_asset = require_once Plugin::instance()->plugin_dir(
			'assets/js/builder.editor.asset.php'
		);

		wp_enqueue_script(
			Plugin::instance()->slug,
			Plugin::instance()->plugin_url( 'assets/js/builder.editor.js' ),
			$script_asset['dependencies'],
			$script_asset['version'],
			true
		);
	}

	public function plugin_version_compare() {
		return '1.2.2';
	}

	public function on_base_need_update() {
		$this->add_admin_notice(
			'warning',
			__(
				'<b>Warning</b>: <b>JetFormBuilder ConvertKit Action</b> needs <b>JetFormBuilder</b> update.',
				'jet-form-builder-convertkit-action'
			)
		);
	}

	public function on_base_need_install() {
	}
}
