<?php

namespace Jet_FB_ConvertKit\Jet_Form_Builder\Actions;

use Jet_FB_ConvertKit\Base_Action;
use JetConvertKitCore\JetFormBuilder\SmartBaseAction;

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Class Action
 *
 * @package Jet_FB_ConvertKit\Jet_Form_Builder\Actions
 */
class Action extends SmartBaseAction {

	use Base_Action;

	public function getGlobalSettingsKeys() {
		return array(
			'api_key' => '',
		);
	}

}
