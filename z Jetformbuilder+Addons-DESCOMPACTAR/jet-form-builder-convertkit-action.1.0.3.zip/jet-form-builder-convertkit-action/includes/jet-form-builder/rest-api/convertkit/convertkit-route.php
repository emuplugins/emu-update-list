<?php

namespace Jet_FB_ConvertKit\Jet_Form_Builder\Rest_Api\Convertkit;

use JFB_Components\Rest_Api\Route;

class Convertkit_Route extends Route {

	public function __construct() {
		$this->set_namespace( 'jet-form-builder/v1' );
		$this->set_route( 'convertkit' );
		$this->add_endpoint( new Convertkit_Endpoint() );
	}

}
