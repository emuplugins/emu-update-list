<?php

namespace Jet_FB_ConvertKit;

use JetConvertKitCore\BaseHandler;
use JetConvertKitCore\Common\Tools;
use JetConvertKitCore\Exceptions\ApiHandlerException;

class Handler extends BaseHandler {

	protected     $api_base_url = 'https://api.convertkit.com/v3/';
	public static $instance;

	public function ajax_action(): string {
		return 'jet_form_builder_get_convertkit_data';
	}

	public function get_api_request_args() {
		return array(
			'headers' => array(
				'Content-Type' => 'application/json; charset=utf-8',
			),
		);
	}

	/**
	 * @return array
	 * @throws ApiHandlerException
	 */
	public function get_all_data() {
		$tags   = $this->get_request( 'tags' );
		$fields = $this->get_request( 'custom_fields' );

		$tags_list = Tools::with_placeholder( Tools::prepare_list_for_js( $tags['tags'], 'id', 'name' ) );

		$fields_list = array_merge(
			array(
				'email'      => array(
					'label'    => 'Email',
					'required' => true,
				),
				'first_name' => array(
					'label' => 'First Name',
				),
			),
			$this->prepare_list( $fields['custom_fields'] )
		);

		return array(
			'tags'   => $tags_list,
			'fields' => $fields_list,
		);
	}

	/**
	 * @param $endpoint
	 * @param array $args
	 *
	 * @return array|false|mixed
	 * @throws ApiHandlerException
	 */
	public function get_request( $endpoint, $args = array() ) {
		$args['body'] = array(
			'api_key' => $this->request_args['api_key'] ?? '',
		);
		$response     = $this->request( $endpoint, $args );

		if ( isset( $response['error'] ) ) {
			throw new ApiHandlerException( "Error on request /$endpoint", $response['error'], $this->get_api_request_args() );
		}

		return $response;
	}

	private function prepare_list( $source, $key_name = 'key' ) {
		$result = array();

		foreach ( $source as $item ) {
			$result[ $item[ $key_name ] ] = $item;
		}

		return $result;
	}

	/**
	 * Instance.
	 *
	 * Ensures only one instance of the plugin class is loaded or can be loaded.
	 *
	 * @return Handler An instance of the class.
	 * @since 1.0.0
	 * @access public
	 * @static
	 */
	public static function instance() {

		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}
}
