# JetFormBuilder ConvertKit Action
Premium Addon for JetFormBuilder

# ChangeLog

## 1.0.3
* UPD: make convertkit action compatible with >= 3.4.0 JetFormBuilder

## 1.0.2
* Tweak: Removed unnecessary hook

## 1.0.1
* Tweak: add license manager