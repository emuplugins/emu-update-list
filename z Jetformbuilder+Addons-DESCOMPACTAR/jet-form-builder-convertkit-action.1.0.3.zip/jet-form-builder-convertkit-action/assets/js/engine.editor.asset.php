<?php return array('dependencies' => array(), 'version' => '015957931db3f88d035c');
