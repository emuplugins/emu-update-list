<?php return array('dependencies' => array(), 'version' => '2bef8376b0baa17e4a88');
