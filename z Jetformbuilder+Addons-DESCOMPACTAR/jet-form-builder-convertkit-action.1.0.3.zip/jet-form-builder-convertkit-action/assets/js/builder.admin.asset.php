<?php return array('dependencies' => array(), 'version' => 'e5e1882a099a5dbacf99');
