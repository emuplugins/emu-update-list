<?php
/**
 * Inline Area template
 */
?>

<div class="jet-search-suggestions__inline-area"><?php echo $this->preview_inline_items_template();?></div>
