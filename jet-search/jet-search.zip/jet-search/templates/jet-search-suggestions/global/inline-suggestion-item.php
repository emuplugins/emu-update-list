<?php
/**
 * Inline Area Item js template
 */
?>

<div class="jet-search-suggestions__inline-area-item" tabindex="0" aria-label="{{{data.fullName}}}">
	<div class="jet-search-suggestions__inline-area-item-title" >{{{data.name}}}</div>
</div>
