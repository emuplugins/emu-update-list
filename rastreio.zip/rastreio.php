<?php
/*
Plugin Name: Melhor Envio Tracker
Description: Formulário simples para rastrear pedidos via API do Melhor Envio.
Version: 1.0
Author: Seu Nome
*/

// Shortcode para exibir o formulário no frontend
function melhor_envio_form_shortcode() {
    $html = '<form method="post">
                <input type="text" name="codigo_rastreio" placeholder="Código de Rastreamento" required />
                <button type="submit">Rastrear</button>
            </form>';

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['codigo_rastreio'])) {
        $codigo_rastreio = sanitize_text_field($_POST['codigo_rastreio']);
        $response = melhor_envio_api_request($codigo_rastreio);

        $html .= '<pre>' . esc_html($response) . '</pre>';
    }

    return $html;
}
add_shortcode('melhor_envio_form', 'melhor_envio_form_shortcode');

// Função para fazer a requisição à API do Melhor Envio
function melhor_envio_api_request($codigo_rastreio) {
    $curl = curl_init();

    curl_setopt_array($curl, [
        CURLOPT_URL => "https://sandbox.melhorenvio.com.br/api/v2/me/orders/search?q=$codigo_rastreio",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_HTTPHEADER => [
            "Accept: application/json",
            "Authorization: Bearer token", // Substitua 'token' pelo seu token real
            "Content-type: application/json",
            "User-Agent: Aplicacao (tonnysantanasantos@gmail.com)"
        ],
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    return $err ? 'Erro: ' . $err : $response;
}
